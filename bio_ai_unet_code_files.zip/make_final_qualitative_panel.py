from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "analysis" / "figures"
OUT = FIG / "final_qualitative_2x2.png"


PANELS = [
    ("True semantic mask", FIG / "sample_true_overlay.png"),
    ("BBox boxes", FIG / "sample_bbox_boxes_overlay.png"),
    ("Semantic U-Net prediction", FIG / "sample_semantic_prediction_overlay.png"),
    ("BBox-supervised prediction", FIG / "sample_bbox_prediction_overlay.png"),
]


def center_crop(im: Image.Image, target_ratio: float) -> Image.Image:
    w, h = im.size
    ratio = w / h
    if ratio > target_ratio:
        new_w = int(h * target_ratio)
        x0 = (w - new_w) // 2
        return im.crop((x0, 0, x0 + new_w, h))
    new_h = int(w / target_ratio)
    y0 = (h - new_h) // 2
    return im.crop((0, y0, w, y0 + new_h))


def main() -> None:
    panel_w, panel_h = 520, 275
    label_h = 38
    gap = 18
    margin = 24
    canvas = Image.new(
        "RGB",
        (margin * 2 + panel_w * 2 + gap, margin * 2 + (panel_h + label_h) * 2 + gap),
        "white",
    )
    draw = ImageDraw.Draw(canvas)
    for i, (label, path) in enumerate(PANELS):
        im = Image.open(path).convert("RGB")
        im = center_crop(im, panel_w / panel_h).resize((panel_w, panel_h), Image.Resampling.LANCZOS)
        col = i % 2
        row = i // 2
        x = margin + col * (panel_w + gap)
        y = margin + row * (panel_h + label_h + gap)
        draw.rounded_rectangle([x, y, x + panel_w, y + panel_h + label_h], radius=10, fill=(246, 248, 250), outline=(220, 225, 232), width=1)
        draw.text((x + 16, y + 10), label, fill=(16, 24, 40))
        canvas.paste(im, (x, y + label_h))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
