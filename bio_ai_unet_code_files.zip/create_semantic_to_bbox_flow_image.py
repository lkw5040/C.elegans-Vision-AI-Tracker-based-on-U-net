from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs" / "semantic_mask_to_bbox_flow.png"


def get_font(size: int, bold: bool = False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\malgunbd.ttf" if bold else r"C:\Windows\Fonts\malgun.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def main() -> None:
    width, height = 1600, 2200
    image = Image.new("RGB", (width, height), "#F7FAFC")
    draw = ImageDraw.Draw(image)

    title_font = get_font(58, True)
    subtitle_font = get_font(30)
    box_font = get_font(39, True)
    small_font = get_font(24)

    navy = "#17324A"
    teal = "#0F766E"
    light_teal = "#DFF5F0"
    box_edge = "#1F4D5A"
    muted = "#64748B"

    draw.rounded_rectangle((90, 70, width - 90, 250), radius=36, fill=navy)
    title = "Semantic Mask to Bounding Box Mask Pipeline"
    bbox = draw.textbbox((0, 0), title, font=title_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, 105), title, font=title_font, fill="white")

    subtitle = "Class-wise component analysis and left-top / right-bottom coordinate extraction"
    bbox = draw.textbbox((0, 0), subtitle, font=subtitle_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, 178), subtitle, font=subtitle_font, fill="#CDEEE8")

    steps = [
        ("01", "Semantic Mask", "Pixel-level label map with class colors"),
        ("02", "Class-wise Binary Mask Generation", "Separate each semantic class into binary masks"),
        ("03", "Connected Component Detection", "Find individual object regions per class"),
        ("04", "Bounding Rectangle Calculation", "Calculate tight rectangle around each component"),
        ("05", "Left-top / Right-bottom Coordinate Extraction", "Export x_min, y_min, x_max, y_max coordinates"),
        ("06", "Filled Bounding Box Mask Generation", "Rasterize boxes into class-colored training masks"),
    ]

    box_w, box_h = 1160, 185
    x0 = (width - box_w) // 2
    start_y = 350
    gap = 105

    for i, (num, label, desc) in enumerate(steps):
        y = start_y + i * (box_h + gap)
        draw.rounded_rectangle((x0 + 12, y + 14, x0 + box_w + 12, y + box_h + 14), radius=28, fill="#D9E3EA")
        draw.rounded_rectangle((x0, y, x0 + box_w, y + box_h), radius=28, fill="white", outline=box_edge, width=4)
        draw.rounded_rectangle((x0 + 38, y + 42, x0 + 170, y + 142), radius=30, fill=light_teal, outline=teal, width=3)
        draw.text((x0 + 104, y + 90), num, font=box_font, fill=teal, anchor="mm")
        draw.text((x0 + 215, y + 48), label, font=box_font, fill=navy)
        draw.text((x0 + 218, y + 107), desc, font=small_font, fill=muted)

        if i < len(steps) - 1:
            ax = width // 2
            ay1 = y + box_h + 18
            ay2 = y + box_h + gap - 18
            draw.line((ax, ay1, ax, ay2), fill=teal, width=8)
            draw.polygon([(ax - 22, ay2 - 2), (ax + 22, ay2 - 2), (ax, ay2 + 38)], fill=teal)

    note = "Output: bounding-box-style mask labels generated from semantic segmentation masks"
    draw.rounded_rectangle((180, height - 185, width - 180, height - 105), radius=24, fill="#EAF6F3", outline="#B8DED7", width=2)
    bbox = draw.textbbox((0, 0), note, font=subtitle_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, height - 165), note, font=subtitle_font, fill=teal)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
