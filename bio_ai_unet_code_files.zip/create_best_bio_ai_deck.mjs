import fs from "node:fs/promises";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

const require = createRequire(import.meta.url);
const { Presentation, PresentationFile } = await import(pathToFileURL(require.resolve("@oai/artifact-tool")).href);

const ROOT = "C:/Users/LEEGIWON/Documents/Codex/2026-06-18/bio-ai-u-net-ppt-mask";
const ANALYSIS = `${ROOT}/work/analysis`;
const FIG = `${ANALYSIS}/figures`;
const WORK = `${ROOT}/work/presentations/best_bio_ai_unet`;
const QA = `${WORK}/tmp/qa`;
const FINAL = `${ROOT}/outputs/BIO_AI_U-Net_라벨링비교_최종본.pptx`;

const W = 1280;
const H = 720;
const C = {
  navy: "#18324A",
  navy2: "#0F2437",
  teal: "#0F766E",
  teal2: "#14B8A6",
  orange: "#F97316",
  orangeSoft: "#FFF7ED",
  red: "#DC2626",
  green: "#16A34A",
  blue: "#2563EB",
  bg: "#F6F8FA",
  white: "#FFFFFF",
  ink: "#101828",
  muted: "#5B667A",
  line: "#D8DEE8",
  paleTeal: "#ECFDF5",
  paleBlue: "#EFF6FF",
};
const FONT = "Malgun Gothic";
const NUM = "Aptos";

async function readJson(path) {
  return JSON.parse(await fs.readFile(path, "utf8"));
}

async function readImageBlob(path) {
  const bytes = await fs.readFile(path);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

function fmt(x, d = 3) {
  return Number(x).toFixed(d);
}

function pct(x, d = 1) {
  return `${(Number(x) * 100).toFixed(d)}%`;
}

function shape(slide, geometry, position, fill, line = "none", extra = {}) {
  return slide.shapes.add({
    geometry,
    position,
    fill,
    line: { style: "solid", fill: line, width: line === "none" ? 0 : 1 },
    ...extra,
  });
}

function text(slide, value, position, style = {}) {
  const t = slide.shapes.add({
    geometry: "textbox",
    position,
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  t.text = value;
  t.text.style = {
    typeface: style.typeface || FONT,
    fontSize: style.fontSize ?? 18,
    color: style.color || C.ink,
    bold: !!style.bold,
    alignment: style.alignment,
  };
  return t;
}

function title(slide, section, main, dark = false) {
  text(slide, section, { left: 64, top: 38, width: 520, height: 26 }, {
    fontSize: 12.5,
    bold: true,
    color: dark ? C.teal2 : C.teal,
  });
  text(slide, main, { left: 64, top: 72, width: 1080, height: 62 }, {
    fontSize: 34,
    bold: true,
    color: dark ? C.white : C.ink,
  });
}

function footer(slide, page, dark = false) {
  text(slide, `BIO AI Capstone | validated pilot experiment | ${page}`, {
    left: 64,
    top: 686,
    width: 620,
    height: 18,
  }, { fontSize: 10.5, color: dark ? "#A7B3C3" : "#7A8495" });
}

function card(slide, position, opts = {}) {
  return shape(slide, "roundRect", position, opts.fill || C.white, opts.line || C.line, {
    borderRadius: "rounded-lg",
    shadow: opts.shadow || undefined,
  });
}

function kpi(slide, value, label, position, color = C.teal, note = "") {
  card(slide, position, { fill: C.white, line: C.line });
  text(slide, value, { left: position.left + 18, top: position.top + 16, width: position.width - 36, height: 58 }, {
    fontSize: 45,
    bold: true,
    color,
    typeface: NUM,
    alignment: "center",
  });
  text(slide, label, { left: position.left + 16, top: position.top + 76, width: position.width - 32, height: 34 }, {
    fontSize: 15.5,
    bold: true,
    color: C.ink,
    alignment: "center",
  });
  if (note) {
    text(slide, note, { left: position.left + 16, top: position.top + 110, width: position.width - 32, height: 34 }, {
      fontSize: 12.5,
      color: C.muted,
      alignment: "center",
    });
  }
}

async function image(slide, path, position, opts = {}) {
  if (opts.frame !== false) card(slide, position, { fill: C.white, line: C.line });
  const inset = opts.frame === false ? 0 : (opts.inset ?? 10);
  slide.images.add({
    blob: await readImageBlob(path),
    contentType: "image/png",
    alt: opts.alt || "analysis figure",
    fit: opts.fit || "contain",
    position: {
      left: position.left + inset,
      top: position.top + inset,
      width: position.width - 2 * inset,
      height: position.height - 2 * inset,
    },
  });
}

function bullet(slide, items, position, opts = {}) {
  const gap = opts.gap || 42;
  items.forEach((item, i) => {
    const y = position.top + i * gap;
    shape(slide, "ellipse", { left: position.left, top: y + 10, width: 8, height: 8 }, opts.color || C.teal, opts.color || C.teal);
    text(slide, item, { left: position.left + 20, top: y, width: position.width - 20, height: gap + 4 }, {
      fontSize: opts.fontSize || 18,
      color: opts.textColor || C.ink,
    });
  });
}

function callout(slide, heading, body, position, color = C.teal, fill = C.white) {
  card(slide, position, { fill, line: color });
  shape(slide, "rect", { left: position.left, top: position.top, width: 8, height: position.height }, color, color);
  text(slide, heading, { left: position.left + 24, top: position.top + 16, width: position.width - 48, height: 30 }, {
    fontSize: 18,
    bold: true,
    color,
  });
  text(slide, body, { left: position.left + 24, top: position.top + 52, width: position.width - 48, height: position.height - 62 }, {
    fontSize: position.height < 95 ? 13.5 : 15.5,
    color: C.ink,
  });
}

function miniTable(slide, headers, rows, position, widths, opts = {}) {
  const rowH = opts.rowH || 42;
  let x = position.left;
  headers.forEach((h, i) => {
    shape(slide, "rect", { left: x, top: position.top, width: widths[i], height: rowH }, opts.headerFill || C.teal, opts.headerFill || C.teal);
    text(slide, h, { left: x + 8, top: position.top + 9, width: widths[i] - 16, height: rowH - 8 }, {
      fontSize: opts.headerSize || 13,
      bold: true,
      color: C.white,
      alignment: "center",
    });
    x += widths[i];
  });
  rows.forEach((row, r) => {
    x = position.left;
    row.forEach((cell, i) => {
      shape(slide, "rect", { left: x, top: position.top + rowH * (r + 1), width: widths[i], height: rowH }, r % 2 ? "#FBFCFD" : C.white, C.line);
      text(slide, String(cell), { left: x + 8, top: position.top + rowH * (r + 1) + 9, width: widths[i] - 16, height: rowH - 8 }, {
        fontSize: opts.bodySize || 12.5,
        color: C.ink,
        alignment: opts.align || "center",
      });
      x += widths[i];
    });
  });
}

function step(slide, number, heading, body, position, color) {
  card(slide, position, { fill: C.white, line: color });
  shape(slide, "ellipse", { left: position.left + 18, top: position.top + 20, width: 44, height: 44 }, color, color);
  text(slide, String(number), { left: position.left + 18, top: position.top + 27, width: 44, height: 28 }, {
    fontSize: 19,
    bold: true,
    color: C.white,
    alignment: "center",
    typeface: NUM,
  });
  text(slide, heading, { left: position.left + 78, top: position.top + 18, width: position.width - 96, height: 30 }, {
    fontSize: 18.5,
    bold: true,
    color,
  });
  text(slide, body, { left: position.left + 78, top: position.top + 52, width: position.width - 96, height: position.height - 60 }, {
    fontSize: 14.5,
    color: C.ink,
  });
}

const summary = await readJson(`${ANALYSIS}/dataset_summary.json`);
const results = await readJson(`${ANALYSIS}/experiment_results.json`);
const overfit = await readJson(`${ANALYSIS}/overfitting_diagnosis.json`);

const semantic = results.models.find((m) => m.model === "semantic_mask");
const bbox = results.models.find((m) => m.model === "bbox_mask");
const sem = semantic.splits.test.metrics_vs_semantic;
const box = bbox.splits.test.metrics_vs_semantic;
const upper = results.bbox_label_upper_bound.rows.find((r) => r.split === "test");
const detSem = results.bbox_detection_metrics.find((r) => r.model === "semantic_mask" && r.iou_threshold === 0.5);
const detBox = results.bbox_detection_metrics.find((r) => r.model === "bbox_mask" && r.iou_threshold === 0.5);

await fs.mkdir(`${ROOT}/outputs`, { recursive: true });
await fs.mkdir(QA, { recursive: true });

const deck = Presentation.create({ slideSize: { width: W, height: H } });

// 1. Cover
{
  const s = deck.slides.add();
  s.background.fill = C.navy;
  shape(s, "rect", { left: 0, top: 0, width: W, height: 10 }, C.teal2, C.teal2);
  title(s, "SOFTWARE CAPSTONE DESIGN · FINAL DECK", "U-Net 기반 BIO AI 라벨링 방식 비교", true);
  text(s, "Semantic segmentation vs bounding-box supervision", { left: 64, top: 164, width: 760, height: 42 }, {
    fontSize: 24,
    color: "#CFE7E4",
    bold: true,
  });
  text(s, "같은 원본 frame과 mask에서 라벨링 방식만 바꿨을 때 segmentation metric과 detection metric이 어떻게 달라지는지 정량 비교", {
    left: 66,
    top: 224,
    width: 670,
    height: 70,
  }, { fontSize: 18, color: "#D7DEE8" });
  await image(s, `${FIG}/sample_true_overlay.png`, { left: 792, top: 84, width: 390, height: 390 }, { frame: false, fit: "cover" });
  shape(s, "rect", { left: 792, top: 474, width: 390, height: 6 }, C.teal2, C.teal2);
  kpi(s, "30", "paired samples", { left: 64, top: 376, width: 180, height: 140 }, C.teal2, "frame + mask");
  kpi(s, "21/4/5", "train / val / test", { left: 270, top: 376, width: 218, height: 140 }, C.orange, "validated split");
  kpi(s, "0.526", "semantic test FG mIoU", { left: 514, top: 376, width: 240, height: 140 }, C.teal, "vs bbox 0.263");
  text(s, "BIO AI 창업 프로젝트 · 2026-06-18", { left: 64, top: 636, width: 520, height: 24 }, { fontSize: 14, color: "#B8C4D2" });
  footer(s, 1, true);
}

// 2. Executive summary
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "00  EXECUTIVE SUMMARY", "발표 핵심 3문장");
  step(s, 1, "Pixel-level 분석은 semantic mask가 우세", `test foreground mIoU ${fmt(sem.foreground_mIoU)} vs ${fmt(box.foreground_mIoU)}, Dice ${fmt(sem.foreground_mean_dice)} vs ${fmt(box.foreground_mean_dice)}.`, { left: 80, top: 166, width: 1060, height: 116 }, C.teal);
  step(s, 2, "BBox는 shape 정보를 잃지만 localization에는 강점", `IoU@0.5 detection F1은 bbox-supervised ${fmt(detBox.mean_f1)}로 semantic ${fmt(detSem.mean_f1)}보다 높다.`, { left: 80, top: 314, width: 1060, height: 116 }, C.orange);
  step(s, 3, "현재 가장 큰 리스크는 rare class와 표본 수", `Blue/L1 class는 전체 pixel의 ${pct(summary.class_pixel_ratios["Larva-L1 / Blue"], 3)}뿐이고 validation은 4장이라 반복 검증이 필요하다.`, { left: 80, top: 462, width: 1060, height: 116 }, C.blue);
  footer(s, 2);
}

// 3. Research question and contribution
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "01  RESEARCH QUESTION", "왜 라벨링 방식을 비교하는가?");
  card(s, { left: 72, top: 150, width: 530, height: 390 }, { fill: C.white, line: C.teal });
  text(s, "연구 질문", { left: 104, top: 184, width: 220, height: 32 }, { fontSize: 22, bold: true, color: C.teal });
  bullet(s, [
    "동일한 U-Net에서 라벨링 방식만 바꾸면 성능은 얼마나 달라지는가?",
    "BBox label은 제작 비용을 줄일 수 있지만, 곡선형 객체의 shape 정보를 얼마나 잃는가?",
    "과적합, 라벨 불균형, 소형 객체 문제는 어떤 지표에서 드러나는가?",
  ], { left: 112, top: 238, width: 438, height: 220 }, { fontSize: 17, gap: 64, color: C.teal });
  card(s, { left: 662, top: 150, width: 530, height: 390 }, { fill: C.white, line: C.orange });
  text(s, "기여", { left: 694, top: 184, width: 220, height: 32 }, { fontSize: 22, bold: true, color: C.orange });
  bullet(s, [
    "30쌍 실제 BIO frame/mask에서 semantic vs bbox 조건을 통제 비교",
    "mask를 left-top/right-bottom bbox로 변환하고 label 자체의 upper bound를 계산",
    "segmentation metric과 detection metric을 분리해 실무적 trade-off를 제시",
  ], { left: 702, top: 238, width: 438, height: 220 }, { fontSize: 17, gap: 64, color: C.orange });
  callout(s, "최종본에서 정리한 기준", "발표 흐름은 간결하게, 수치와 그래프는 검증된 실험 결과만 사용했다.", { left: 148, top: 582, width: 980, height: 72 }, C.navy, C.white);
  footer(s, 3);
}

// 4. Dataset split
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "02  DATASET", "데이터셋 구성과 정확한 split");
  await image(s, `${FIG}/split_distribution.png`, { left: 78, top: 144, width: 444, height: 330 });
  kpi(s, "21", "Train", { left: 568, top: 154, width: 174, height: 136 }, C.teal, "frame_00000-00020");
  kpi(s, "4", "Validation", { left: 770, top: 154, width: 174, height: 136 }, C.orange, "frame_00021-00024");
  kpi(s, "5", "Test", { left: 972, top: 154, width: 174, height: 136 }, C.red, "frame_00025-00029");
  miniTable(s, ["항목", "값", "발표에서의 의미"], [
    ["Total", "30 pairs", "원본 frame 30장 + semantic mask 30장"],
    ["Resolution", "1024 x 1024", "모델 평가에는 384 px resize"],
    ["Split", "Chronological", "연속 frame leakage를 줄이기 위한 파일명 순서 분할"],
    ["Confidence", "Pilot scale", "논문급 일반화 전 반복 split과 데이터 확대 필요"],
  ], { left: 568, top: 338, width: 598, height: 190 }, [140, 140, 318], { rowH: 43, bodySize: 12.8 });
  callout(s, "필수 보고 문장", "전체 30개 paired data 중 21개를 학습, 4개를 validation, 5개를 test에 사용했다.", { left: 78, top: 560, width: 1088, height: 74 }, C.teal);
  footer(s, 4);
}

// 5. Label schema
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "03  LABEL SCHEMA", "Semantic mask와 bbox label의 차이");
  await image(s, `${FIG}/sample_true_overlay.png`, { left: 70, top: 140, width: 350, height: 350 }, { fit: "cover" });
  await image(s, `${FIG}/sample_bbox_boxes_overlay.png`, { left: 462, top: 140, width: 350, height: 350 }, { fit: "cover" });
  miniTable(s, ["RGB", "Class", "특징"], [
    ["#FF0000", "Adult worm", "길고 휘어진 주 객체"],
    ["#00FF00", "Egg / small", "작고 많은 점형 객체"],
    ["#0000FF", "L1 / larva", "가장 희소한 얇은 객체"],
  ], { left: 854, top: 164, width: 330, height: 170 }, [92, 116, 122], { rowH: 42, bodySize: 11.5 });
  callout(s, "핵심 차이", "Semantic mask는 실제 픽셀 형태를 보존한다. BBox는 좌상단/우하단 좌표만으로 객체를 감싸기 때문에 내부 배경이 positive label로 섞인다.", { left: 854, top: 382, width: 330, height: 120 }, C.orange, C.orangeSoft);
  text(s, "왼쪽: 원본+semantic mask overlay / 가운데: 같은 객체를 bounding box로 표현", { left: 90, top: 520, width: 730, height: 30 }, { fontSize: 15.5, color: C.muted });
  footer(s, 5);
}

// 6. Data diagnostics
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "04  DATA DIAGNOSTICS", "극단적 배경 우세와 소형 객체 리스크");
  await image(s, `${FIG}/class_pixel_distribution.png`, { left: 70, top: 132, width: 520, height: 320 });
  await image(s, `${FIG}/object_size_histogram.png`, { left: 630, top: 132, width: 520, height: 320 });
  kpi(s, pct(1 - summary.class_pixel_ratios.Background, 3), "foreground pixels", { left: 112, top: 498, width: 230, height: 134 }, C.orange, "background ≈ 99.205%");
  kpi(s, String(summary.class_object_counts["Egg-small object / Green"]), "green small objects", { left: 404, top: 498, width: 230, height: 134 }, C.green, "many but tiny");
  kpi(s, pct(summary.class_pixel_ratios["Larva-L1 / Blue"], 3), "Blue/L1 pixel ratio", { left: 696, top: 498, width: 230, height: 134 }, C.blue, "rare-class bottleneck");
  kpi(s, String(summary.bbox_count), "converted boxes", { left: 988, top: 498, width: 180, height: 134 }, C.teal, "from masks");
  footer(s, 6);
}

// 7. BBox conversion and information loss
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "05  BOUNDING BOX CONVERSION", "Left-top / Right-bottom 변환이 만드는 정보 손실");
  await image(s, `${FIG}/bbox_tightness_by_class.png`, { left: 70, top: 130, width: 520, height: 340 });
  await image(s, `${FIG}/bbox_inflation.png`, { left: 630, top: 130, width: 500, height: 340 });
  const adultT = summary.bbox_tightness_mean["Adult worm / Red"];
  const adultI = summary.bbox_inflation_mean["Adult worm / Red"];
  callout(s, "Adult worm에서 특히 심각", `평균 bbox tightness는 ${fmt(adultT)}이고 bbox 면적은 mask 대비 ${fmt(adultI, 1)}배다. 얇고 휘어진 객체일수록 직사각형 안의 배경 noise가 커진다.`, { left: 112, top: 520, width: 1010, height: 86 }, C.orange, C.orangeSoft);
  footer(s, 7);
}

// 8. Experimental protocol
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "06  EXPERIMENTAL PROTOCOL", "같은 U-Net, 다른 supervision");
  const items = [
    ["Input", "RGB frame\n384 px resize", C.teal],
    ["Model", "Compact U-Net\nencoder-decoder", C.navy],
    ["Loss", "Weighted CE\n+ Dice", C.orange],
    ["Sampling", "160 px patch\nforeground-biased", C.green],
    ["Epoch", "28 epochs\nCPU pilot", C.blue],
  ];
  items.forEach((it, i) => {
    const x = 78 + i * 222;
    card(s, { left: x, top: 150, width: 184, height: 150 }, { fill: C.white, line: it[2] });
    text(s, it[0], { left: x + 16, top: 172, width: 152, height: 28 }, { fontSize: 20, bold: true, color: it[2], alignment: "center" });
    text(s, it[1], { left: x + 16, top: 214, width: 152, height: 58 }, { fontSize: 16, color: C.ink, alignment: "center" });
  });
  miniTable(s, ["Condition", "Training target", "Evaluation target", "Interpretation"], [
    ["Semantic U-Net", "pixel mask", "semantic mask", "형태 보존 segmentation"],
    ["BBox-supervised U-Net", "bbox-filled mask", "semantic mask + bbox F1", "빠른 라벨의 손실 측정"],
    ["BBox label upper bound", "model 없음", "semantic mask", "bbox 자체의 구조적 한계"],
  ], { left: 118, top: 390, width: 1044, height: 160 }, [250, 250, 250, 294], { rowH: 44, bodySize: 13.2 });
  callout(s, "학습 보정", "라벨 불균형을 줄이기 위해 class weight와 foreground-biased patch sampling을 적용했다.", { left: 118, top: 584, width: 1044, height: 66 }, C.teal);
  footer(s, 8);
}

// 9. Training curves
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "07  OVERFITTING CHECK", "train/validation loss로 본 과적합 여부");
  await image(s, `${FIG}/training_loss_curves.png`, { left: 70, top: 132, width: 660, height: 400 });
  kpi(s, String(overfit.semantic_mask.best_epoch), "Semantic best epoch", { left: 790, top: 150, width: 180, height: 128 }, C.teal, `gap ${fmt(overfit.semantic_mask.final_gap_validation_minus_train)}`);
  kpi(s, String(overfit.bbox_mask.best_epoch), "BBox best epoch", { left: 994, top: 150, width: 180, height: 128 }, C.orange, `gap ${fmt(overfit.bbox_mask.final_gap_validation_minus_train)}`);
  callout(s, "진단", "두 조건 모두 validation loss가 후반에 악화되지 않았고 train-validation gap도 작았다. 현재 실험에서는 강한 과적합 신호는 없다.", { left: 790, top: 326, width: 384, height: 122 }, C.teal);
  callout(s, "주의", "validation이 4장이므로 과적합 판단의 신뢰도는 제한적이다. 발표에서는 '강한 신호 없음, 단 표본 부족'으로 표현한다.", { left: 790, top: 478, width: 384, height: 104 }, C.navy);
  footer(s, 9);
}

// 10. Main test result
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "08  MAIN RESULT", "Pixel-level segmentation은 semantic mask가 우세");
  await image(s, `${FIG}/test_metric_comparison.png`, { left: 70, top: 136, width: 600, height: 374 });
  miniTable(s, ["Metric", "Semantic", "BBox", "BBox upper"], [
    ["Pixel Acc.", pct(sem.pixel_accuracy, 2), pct(box.pixel_accuracy, 2), pct(upper.pixel_accuracy, 2)],
    ["FG mIoU", fmt(sem.foreground_mIoU), fmt(box.foreground_mIoU), fmt(upper.foreground_mIoU)],
    ["FG Dice", fmt(sem.foreground_mean_dice), fmt(box.foreground_mean_dice), fmt(upper.foreground_mean_dice)],
    ["FG Precision", fmt(sem.foreground_mean_precision), fmt(box.foreground_mean_precision), fmt(upper.foreground_mean_precision)],
  ], { left: 720, top: 154, width: 460, height: 224 }, [120, 110, 110, 120], { rowH: 42, bodySize: 12.8 });
  callout(s, "해석", `Semantic U-Net은 test FG mIoU ${fmt(sem.foreground_mIoU)}로 bbox-supervised ${fmt(box.foreground_mIoU)}보다 높다. bbox upper-bound도 ${fmt(upper.foreground_mIoU)}라 label 자체의 정보 손실이 확인된다.`, { left: 720, top: 430, width: 460, height: 112 }, C.teal);
  footer(s, 10);
}

// 11. Per-class analysis
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "09  PER-CLASS ANALYSIS", "Adult/Egg는 학습되지만 Blue/L1은 병목");
  await image(s, `${FIG}/per_class_iou.png`, { left: 72, top: 128, width: 620, height: 398 });
  miniTable(s, ["Class", "Semantic IoU", "BBox IoU", "Point"], [
    ["Adult", fmt(sem.iou_class_1), fmt(box.iou_class_1), "shape mask가 압도적"],
    ["Egg", fmt(sem.iou_class_2), fmt(box.iou_class_2), "작지만 개수 많음"],
    ["L1", fmt(sem.iou_class_3), fmt(box.iou_class_3), "희소 label 실패"],
  ], { left: 738, top: 156, width: 430, height: 170 }, [92, 112, 92, 134], { rowH: 42, bodySize: 12 });
  callout(s, "Blue/L1 병목", `Blue/L1 class는 전체 pixel의 ${pct(summary.class_pixel_ratios["Larva-L1 / Blue"], 3)}뿐이다. 현재 test에서는 rare class recall이 불안정하므로 추가 라벨링이 최우선이다.`, { left: 738, top: 386, width: 430, height: 122 }, C.blue, C.paleBlue);
  footer(s, 11);
}

// 12. Detection view
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "10  DETECTION VIEW", "BBox 관점에서는 다른 결론이 나온다");
  await image(s, `${FIG}/bbox_detection_f1.png`, { left: 78, top: 132, width: 560, height: 390 });
  kpi(s, fmt(detSem.mean_f1), "Semantic detection F1", { left: 720, top: 152, width: 212, height: 132 }, C.teal, "IoU@0.5");
  kpi(s, fmt(detBox.mean_f1), "BBox-supervised F1", { left: 960, top: 152, width: 212, height: 132 }, C.orange, "IoU@0.5");
  callout(s, "Trade-off", "BBox-supervised model은 객체 위치 recall과 box F1에서 장점이 있다. 하지만 pixel-level mask precision은 낮으므로 검출 KPI와 segmentation KPI를 분리해서 해석해야 한다.", { left: 720, top: 346, width: 452, height: 132 }, C.orange, C.orangeSoft);
  callout(s, "발표용 한 줄", "정밀 생물학적 형태 분석은 semantic mask, 빠른 위치 검출/사전 라벨링은 bbox가 보조적으로 적합하다.", { left: 720, top: 506, width: 452, height: 74 }, C.navy);
  footer(s, 12);
}

// 13. Qualitative overlay
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "11  QUALITATIVE CHECK", "정성 결과가 metric 해석을 뒷받침한다");
  await image(s, `${FIG}/final_qualitative_2x2.png`, { left: 68, top: 130, width: 792, height: 500 }, { frame: false });
  callout(s, "관찰", "Semantic prediction은 얇은 red/green 형태를 비교적 따라간다. BBox-supervised prediction은 red 영역을 직사각형처럼 넓게 잡아 내부 배경 noise가 출력된다.", { left: 900, top: 168, width: 300, height: 156 }, C.teal);
  callout(s, "발표 포인트", "이 슬라이드에서 metric 숫자가 실제 이미지에서 어떤 차이를 뜻하는지 설명하면 청중이 바로 이해한다.", { left: 900, top: 366, width: 300, height: 116 }, C.orange, C.orangeSoft);
  footer(s, 13);
}

// 14. Interpretation
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "12  INTERPRETATION", "왜 bbox는 shape precision에서 불리한가?");
  step(s, 1, "Thin curved objects", "선충처럼 가늘고 휘어진 객체는 직사각형 bbox 안에 넓은 배경을 포함한다.", { left: 92, top: 156, width: 500, height: 108 }, C.teal);
  step(s, 2, "Label noise by construction", "BBox-filled mask로 학습하면 실제 배경도 positive pixel로 학습된다.", { left: 650, top: 156, width: 500, height: 108 }, C.orange);
  step(s, 3, "Metric mismatch", "Detection F1은 위치를 보지만 mIoU/Dice는 픽셀 shape를 본다. 지표를 섞으면 결론이 흐려진다.", { left: 92, top: 304, width: 500, height: 108 }, C.blue);
  step(s, 4, "Rare labels dominate failure", "Blue/L1처럼 작은 class는 전체 loss에서 쉽게 묻힌다. class-specific acquisition이 필요하다.", { left: 650, top: 304, width: 500, height: 108 }, C.navy);
  callout(s, "핵심 해석", "BBox는 '객체가 어디 있는가'에는 빠르고 강하지만, '객체 형태가 정확히 어디까지인가'에는 구조적으로 불리하다.", { left: 164, top: 512, width: 940, height: 82 }, C.teal, C.paleTeal);
  footer(s, 14);
}

// 15. Workflow recommendation
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "13  STARTUP WORKFLOW", "BIO AI 제품화 관점의 권장 workflow");
  const xs = [72, 316, 560, 804, 1048];
  const labels = [
    ["1", "BBox quick label", "빠른 위치 annotation"],
    ["2", "Model pre-label", "U-Net/Detector 초벌 예측"],
    ["3", "Mask refinement", "중요 frame은 mask 보정"],
    ["4", "Rare-class review", "Blue/L1 우선 검수"],
    ["5", "Validated split", "영상 단위 test"],
  ];
  labels.forEach((it, i) => {
    card(s, { left: xs[i], top: 178, width: 180, height: 160 }, { fill: i === 2 ? C.paleTeal : C.white, line: i === 2 ? C.teal : C.line });
    shape(s, "ellipse", { left: xs[i] + 66, top: 198, width: 48, height: 48 }, i === 2 ? C.teal : C.navy, i === 2 ? C.teal : C.navy);
    text(s, it[0], { left: xs[i] + 66, top: 206, width: 48, height: 28 }, { fontSize: 19, bold: true, color: C.white, alignment: "center", typeface: NUM });
    text(s, it[1], { left: xs[i] + 12, top: 260, width: 156, height: 30 }, { fontSize: 15, bold: true, color: i === 2 ? C.teal : C.ink, alignment: "center" });
    text(s, it[2], { left: xs[i] + 14, top: 294, width: 152, height: 34 }, { fontSize: 12.2, color: C.muted, alignment: "center" });
    if (i < 4) text(s, "→", { left: xs[i] + 188, top: 224, width: 40, height: 42 }, { fontSize: 30, bold: true, color: C.muted, alignment: "center" });
  });
  callout(s, "권장 결론", "최종 학습 label은 mask-first가 적합하다. 다만 bbox는 빠른 초벌 annotation, object proposal, 검출용 KPI에 보조적으로 사용하면 효율이 좋다.", { left: 96, top: 430, width: 1020, height: 96 }, C.teal);
  bullet(s, [
    "추가 라벨링 예산은 Blue/L1 rare class와 edge-case frame에 우선 투입",
    "서비스 demo에서는 segmentation overlay와 detection box를 함께 보여주면 설득력이 높음",
  ], { left: 136, top: 560, width: 940, height: 80 }, { fontSize: 17, gap: 36, color: C.orange });
  footer(s, 15);
}

// 16. Limitations and next experiments
{
  const s = deck.slides.add();
  s.background.fill = C.bg;
  title(s, "14  LIMITATIONS", "한계와 다음 실험");
  const lims = [
    ["표본 수", "30장 pilot이므로 일반화 결론은 제한적. 최소 수백 frame + 반복 split 필요.", C.orange],
    ["Validation 크기", "validation 4장이라 과적합 판단 신뢰도가 낮음. video/block 단위 split 권장.", C.teal],
    ["Rare class", "Blue/L1 class pixel이 0.059%뿐이라 class-specific sampling과 추가 라벨링 필요.", C.blue],
    ["라벨 방식", "BBox는 곡선형 객체에서 구조적 한계. centerline/keypoint/instance mask도 후보.", C.navy],
  ];
  lims.forEach((it, i) => {
    const x = i % 2 === 0 ? 84 : 650;
    const y = i < 2 ? 160 : 356;
    card(s, { left: x, top: y, width: 500, height: 140 }, { fill: C.white, line: it[2] });
    shape(s, "rect", { left: x, top: y, width: 8, height: 140 }, it[2], it[2]);
    text(s, it[0], { left: x + 30, top: y + 22, width: 420, height: 32 }, { fontSize: 20, bold: true, color: it[2] });
    text(s, it[1], { left: x + 30, top: y + 64, width: 420, height: 52 }, { fontSize: 15.5, color: C.ink });
  });
  callout(s, "다음 발표/논문용 보강", "데이터 확장 후 3회 이상 반복 split, class별 confidence interval, 그리고 annotation time 대비 성능 효율 그래프를 추가하면 논문형 완성도가 올라간다.", { left: 156, top: 558, width: 940, height: 82 }, C.teal, C.paleTeal);
  footer(s, 16);
}

// 17. Closing
{
  const s = deck.slides.add();
  s.background.fill = C.navy;
  shape(s, "rect", { left: 0, top: 0, width: W, height: 10 }, C.teal2, C.teal2);
  title(s, "15  CONCLUSION", "최종 결론", true);
  kpi(s, fmt(sem.foreground_mIoU), "Semantic test FG mIoU", { left: 92, top: 178, width: 300, height: 152 }, C.teal, "pixel-level 우세");
  kpi(s, fmt(box.foreground_mIoU), "BBox-supervised FG mIoU", { left: 490, top: 178, width: 300, height: 152 }, C.orange, "shape precision 손실");
  kpi(s, fmt(detBox.mean_f1), "BBox detection F1", { left: 888, top: 178, width: 300, height: 152 }, C.navy, "localization 우세");
  text(s, "Decision", { left: 102, top: 404, width: 220, height: 34 }, { fontSize: 22, bold: true, color: C.teal2 });
  bullet(s, [
    "정밀 생물학적 형태 분석과 mask 기반 정량화에는 semantic segmentation을 기본으로 사용한다.",
    "BBox는 빠른 라벨링, object proposal, detection KPI용 보조 도구로 사용하는 것이 가장 합리적이다.",
    "상용화/논문화 전에는 rare class 보강과 video-level split 검증이 필요하다.",
  ], { left: 106, top: 456, width: 1030, height: 140 }, { fontSize: 19, gap: 48, color: C.teal2, textColor: C.white });
  text(s, "Reproducibility: split_manifest.csv, bbox_annotations_left_top_right_bottom.csv, training_history.csv, model_metrics_summary.csv", {
    left: 96,
    top: 644,
    width: 1040,
    height: 24,
  }, { fontSize: 12, color: "#B8C4D2", alignment: "center" });
  footer(s, 17, true);
}

const pptx = await PresentationFile.exportPptx(deck);
await pptx.save(FINAL);

await fs.writeFile(`${QA}/visual-qa.txt`, [
  "Visual QA notes for final best deck",
  "- Final deck was created with @oai/artifact-tool and exported with PresentationFile.exportPptx.",
  "- Source decks were inspected and rendered for comparison; final values come from validated work/analysis data.",
  "- Artifact-tool PNG rendering is intentionally not used because this local runtime exits on Vulkan initialization. PowerPoint PNG export is used for QA after PPTX generation.",
  "- Expected final slide count: 17.",
].join("\n"), "utf8");

console.log(JSON.stringify({ final: FINAL, slides: deck.slides.items.length }, null, 2));
