from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs" / "segmentation_detection_metrics_overview.png"


def get_font(size: int, bold: bool = False):
    candidates = [
        r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\malgunbd.ttf" if bold else r"C:\Windows\Fonts\malgun.ttf",
    ]
    for path in candidates:
        if Path(path).exists():
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def wrap(draw: ImageDraw.ImageDraw, text: str, font, max_width: int) -> list[str]:
    words = text.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        trial = f"{current} {word}".strip()
        if draw.textbbox((0, 0), trial, font=font)[2] <= max_width:
            current = trial
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def main() -> None:
    width, height = 1800, 1350
    image = Image.new("RGB", (width, height), "#F7FAFC")
    draw = ImageDraw.Draw(image)

    title_font = get_font(60, True)
    subtitle_font = get_font(28)
    section_font = get_font(34, True)
    metric_font = get_font(28, True)
    desc_font = get_font(21)
    small_font = get_font(18)

    navy = "#17324A"
    teal = "#0F766E"
    blue = "#2563EB"
    muted = "#64748B"

    draw.rounded_rectangle((80, 55, width - 80, 195), radius=34, fill=navy)
    title = "Model Evaluation Metrics & Prediction Review"
    bbox = draw.textbbox((0, 0), title, font=title_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, 82), title, font=title_font, fill="white")

    subtitle = "Segmentation quality, detection reliability, and qualitative overlay inspection"
    bbox = draw.textbbox((0, 0), subtitle, font=subtitle_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, 154), subtitle, font=subtitle_font, fill="#CDEEE8")

    def section_header(x: int, y: int, text: str, color: str) -> None:
        draw.rounded_rectangle((x, y, x + 420, y + 54), radius=18, fill=color)
        draw.text((x + 26, y + 12), text, font=section_font, fill="white")

    def draw_card(x: int, y: int, w: int, h: int, border: str, tag: str, title: str, desc: str, accent: str) -> None:
        draw.rounded_rectangle((x + 8, y + 10, x + w + 8, y + h + 10), radius=24, fill="#DCE7EE")
        draw.rounded_rectangle((x, y, x + w, y + h), radius=24, fill="white", outline=border, width=3)
        draw.rounded_rectangle((x + 22, y + 20, x + 82, y + 60), radius=14, fill=accent)
        draw.text((x + 52, y + 40), tag, font=small_font, fill="white", anchor="mm")
        draw.text((x + 105, y + 18), title, font=metric_font, fill=navy)
        for i, line in enumerate(wrap(draw, desc, desc_font, w - 130)[:3]):
            draw.text((x + 106, y + 60 + i * 27), line, font=desc_font, fill=muted)

    left_x, right_x = 100, 940
    section_header(left_x, 245, "Segmentation Metrics", teal)
    section_header(right_x, 245, "Detection Metrics", blue)

    seg_cards = [
        ("S1", "Foreground mIoU", "Mean IoU over foreground classes only; reduces background dominance.", teal),
        ("S2", "Foreground Dice Score", "Overlap score for foreground masks; useful for small object segmentation.", "#14B8A6"),
        ("S3", "Per-class IoU", "IoU for Adult, Egg, and L1 to reveal class-specific weakness.", "#4F46E5"),
        ("S4", "Foreground Precision", "How many predicted foreground pixels are actually foreground.", "#16A34A"),
    ]
    det_cards = [
        ("D1", "Detection Precision", "Ratio of predicted objects that correctly match ground-truth objects.", blue),
        ("D2", "Detection Recall", "Ratio of real objects detected by the model.", "#F97316"),
        ("D3", "Detection F1 Score", "Balanced score between detection precision and recall.", "#DC2626"),
    ]
    for i, card in enumerate(seg_cards):
        draw_card(left_x, 320 + i * 150, 760, 128, "#BFD8D4", *card)
    for i, card in enumerate(det_cards):
        draw_card(right_x, 320 + i * 150, 760, 128, "#C7D7F7", *card)

    band_y = 925
    draw.rounded_rectangle((100, band_y, width - 100, height - 115), radius=30, fill="white", outline="#BFD8D4", width=3)
    draw.text((145, band_y + 32), "Prediction Overlay Result", font=section_font, fill=navy)
    draw.text(
        (145, band_y + 80),
        "Original image + predicted mask overlay for visual validation of boundary quality, missed objects, and false positives.",
        font=desc_font,
        fill=muted,
    )

    panel_y = band_y + 140
    panel_w, panel_h = 360, 190
    panels = [
        ("Original", "#CBD5E1"),
        ("Ground Truth Mask", "#A7F3D0"),
        ("Prediction Mask", "#BFDBFE"),
        ("Overlay Review", "#FDE68A"),
    ]
    for i, (label, fill) in enumerate(panels):
        x = 155 + i * (panel_w + 45)
        draw.rounded_rectangle((x + 5, panel_y + 7, x + panel_w + 5, panel_y + panel_h + 7), radius=18, fill="#DCE7EE")
        draw.rounded_rectangle((x, panel_y, x + panel_w, panel_y + panel_h), radius=18, fill=fill, outline="#64748B", width=2)
        draw.rectangle((x + 22, panel_y + 32, x + panel_w - 22, panel_y + panel_h - 45), fill="#D9E1DF", outline="#94A3B8")
        for j in range(3):
            ox = x + 65 + j * 80 + (15 if i % 2 else 0)
            oy = panel_y + 72 + (j % 2) * 38
            draw.arc((ox, oy, ox + 95, oy + 45), 200, 350, fill="#DC2626", width=7)
        for j in range(8):
            gx = x + 45 + (j * 37) % 270
            gy = panel_y + 60 + (j * 23) % 90
            draw.ellipse((gx, gy, gx + 8, gy + 8), fill="#22C55E")
        if label == "Overlay Review":
            draw.rounded_rectangle((x + 52, panel_y + 65, x + 135, panel_y + 112), radius=4, outline="#DC2626", width=3)
            draw.rounded_rectangle((x + 198, panel_y + 88, x + 300, panel_y + 130), radius=4, outline="#2563EB", width=3)
        bbox = draw.textbbox((0, 0), label, font=small_font)
        draw.text((x + (panel_w - (bbox[2] - bbox[0])) / 2, panel_y + panel_h - 34), label, font=small_font, fill=navy)

    summary = "Use metrics for quantitative comparison, then inspect prediction overlays to verify real visual behavior."
    draw.rounded_rectangle((190, height - 80, width - 190, height - 28), radius=18, fill="#EAF6F3", outline="#B8DED7")
    bbox = draw.textbbox((0, 0), summary, font=desc_font)
    draw.text(((width - (bbox[2] - bbox[0])) / 2, height - 67), summary, font=desc_font, fill=teal)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    image.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
