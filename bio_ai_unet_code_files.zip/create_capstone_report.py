# -*- coding: utf-8 -*-
from __future__ import annotations

import csv
import json
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[2]
TEMPLATE = ROOT / "work" / "capstone_template.docx"
ANALYSIS = ROOT / "work" / "analysis"
FIG = ANALYSIS / "figures"
OUT = ROOT / "outputs" / "BIO_AI_U-Net_캡스톤디자인_최종보고서_Celegans강조_22p.docx"

FONT = "맑은 고딕"
TITLE_COLOR = RGBColor(23, 50, 74)
ACCENT = RGBColor(15, 118, 110)
MUTED = RGBColor(89, 99, 110)


def read_json(name: str):
    with (ANALYSIS / name).open("r", encoding="utf-8") as f:
        return json.load(f)


def read_csv_rows(name: str):
    with (ANALYSIS / name).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


dataset = read_json("dataset_summary.json")
overfit = read_json("overfitting_diagnosis.json")
metrics_rows = read_csv_rows("model_metrics_summary.csv")
per_class_rows = read_csv_rows("per_class_test_metrics.csv")
detection_rows = read_csv_rows("bbox_detection_metrics.csv")


def find_metric(model: str, split: str) -> dict:
    for row in metrics_rows:
        if row["model"] == model and row["split"] == split:
            return row
    raise KeyError((model, split))


semantic_test = find_metric("semantic_mask", "test")
bbox_test = find_metric("bbox_mask", "test")
upper_test = find_metric("bbox_label_upper_bound", "test")


def pct(value: float | str, digits: int = 2) -> str:
    return f"{float(value) * 100:.{digits}f}%"


def num(value: float | str, digits: int = 3) -> str:
    return f"{float(value):.{digits}f}"


def clear_doc(doc: Document) -> None:
    body = doc._body._element
    for child in list(body):
        if child.tag == qn("w:sectPr"):
            continue
        body.remove(child)


def ensure_rfonts(run) -> None:
    r_pr = run._element.get_or_add_rPr()
    r_fonts = r_pr.rFonts
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        r_pr.append(r_fonts)
    r_fonts.set(qn("w:eastAsia"), FONT)
    r_fonts.set(qn("w:ascii"), FONT)
    r_fonts.set(qn("w:hAnsi"), FONT)


def set_run(run, size: float | None = None, bold: bool = False, color: RGBColor | None = None, italic: bool = False) -> None:
    run.font.name = FONT
    ensure_rfonts(run)
    if size is not None:
        run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color is not None:
        run.font.color.rgb = color


def shade_cell(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell(cell, text: str, bold: bool = False, color: RGBColor | None = None, fill: str | None = None, size: float = 8.0) -> None:
    cell.text = ""
    if fill:
        shade_cell(cell, fill)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER if bold else WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    run = p.add_run(text)
    set_run(run, size=size, bold=bold, color=color)


def add_table(doc: Document, headers: list[str], rows: list[list[str]], widths: list[float] | None = None) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, header in enumerate(headers):
        set_cell(table.rows[0].cells[i], header, bold=True, color=RGBColor(255, 255, 255), fill="17324A", size=7.7)
        if widths:
            table.rows[0].cells[i].width = Cm(widths[i])
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            set_cell(cells[i], value, size=7.5)
            if widths:
                cells[i].width = Cm(widths[i])
    doc.add_paragraph()


def paragraph(
    doc: Document,
    text: str = "",
    size: float = 8.9,
    bold: bool = False,
    color: RGBColor | None = None,
    align: int | None = None,
    first_line: bool = True,
    after: float = 4.0,
    before: float = 0.0,
) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.02
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(before)
    if first_line:
        p.paragraph_format.first_line_indent = Cm(0.35)
    if align is not None:
        p.alignment = align
    run = p.add_run(text)
    set_run(run, size=size, bold=bold, color=color)


def bullet(doc: Document, text: str, level: int = 0) -> None:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.55 + level * 0.35)
    p.paragraph_format.first_line_indent = Cm(-0.25)
    p.paragraph_format.space_after = Pt(1.5)
    p.paragraph_format.line_spacing = 1.05
    run = p.add_run("• " + text)
    set_run(run, size=8.45)


def heading(doc: Document, text: str, level: int = 1) -> None:
    if level == 1:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(8)
        run = p.add_run(text)
        set_run(run, size=14.4, bold=True, color=TITLE_COLOR)
    elif level == 2:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(5)
        p.paragraph_format.space_after = Pt(5)
        run = p.add_run(text)
        set_run(run, size=11.2, bold=True, color=ACCENT)
    else:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(3)
        run = p.add_run(text)
        set_run(run, size=10.4, bold=True, color=TITLE_COLOR)


def caption(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(5)
    run = p.add_run(text)
    set_run(run, size=7.8, color=MUTED)


def add_picture(doc: Document, filename: str, width_cm: float = 15.2, cap: str | None = None) -> None:
    path = FIG / filename
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    run.add_picture(str(path), width=Cm(width_cm * 0.76))
    if cap:
        caption(doc, cap)


PAGE_BREAK_CALL = 0
HARD_PAGE_BREAKS = {
    1,   # cover
}


def page_break(doc: Document) -> None:
    global PAGE_BREAK_CALL
    PAGE_BREAK_CALL += 1
    if PAGE_BREAK_CALL in HARD_PAGE_BREAKS:
        doc.add_page_break()
    else:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)


def callout(doc: Document, title: str, body: str) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    cell = table.cell(0, 0)
    shade_cell(cell, "EAF6F3")
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    r1 = p.add_run(title + "  ")
    set_run(r1, size=9.2, bold=True, color=ACCENT)
    r2 = p.add_run(body)
    set_run(r2, size=9.2)
    doc.add_paragraph()


def setup_document() -> Document:
    doc = Document(str(TEMPLATE))
    clear_doc(doc)
    section = doc.sections[0]
    section.start_type = WD_SECTION_START.NEW_PAGE
    section.top_margin = Cm(1.25)
    section.bottom_margin = Cm(1.05)
    section.left_margin = Cm(1.50)
    section.right_margin = Cm(1.50)

    styles = doc.styles
    for name in ["Normal", "List Bullet", "Table Grid"]:
        if name in styles:
            style = styles[name]
            if hasattr(style, "font"):
                style.font.name = FONT
                style.font.size = Pt(10)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.text = ""
    run = footer.add_run("소프트웨어캡스톤디자인 최종보고서 | BIO AI 창업 프로젝트")
    set_run(run, size=8.0, color=MUTED)
    return doc


def add_cover(doc: Document) -> None:
    for _ in range(3):
        paragraph(doc, "", first_line=False, after=0)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("< 캡스톤디자인 최종보고서 >")
    set_run(r, size=19, bold=True, color=TITLE_COLOR)
    paragraph(doc, "BIO AI 창업 프로젝트", size=20, bold=True, color=ACCENT, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, after=2, before=16)
    paragraph(doc, "C. elegans 추적 AI를 위한 U-Net 기반 객체 분할 및 라벨링 방식 비교", size=15, bold=True, color=TITLE_COLOR, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, after=16)
    paragraph(doc, "예쁜꼬마선충 영상에서 Adult, Egg, L1 객체를 자동 검출하기 위한 정량 평가, 과적합 진단, 라벨링 방식별 한계 분석", size=10.5, color=MUTED, align=WD_ALIGN_PARAGRAPH.CENTER, first_line=False, after=18)

    add_table(
        doc,
        ["구분", "내용"],
        [
            ["프로젝트 명", "BIO AI 창업 프로젝트: C. elegans 추적 AI와 라벨링 방식 비교"],
            ["과목", "소프트웨어캡스톤디자인"],
            ["팀원(참여학생)", "이기원"],
            ["분석 자료", r"C:\Users\LEEGIWON\Documents\기원문서\maks_frame"],
            ["작성일", str(date.today())],
        ],
        widths=[4.2, 11.2],
    )
    paragraph(
        doc,
        "본 보고서는 BIO AI 창업 프로젝트에서 다룬 C. elegans 영상 분석 문제를 캡스톤디자인 보고서 양식에 맞추어 재정리한 것이다. "
        "특히 C. elegans의 성장 단계와 개체 위치를 자동으로 파악하기 위해 마스크 기반 학습과 bbox 기반 학습을 같은 데이터 분할에서 비교하고, 어떤 라벨링 방식이 추적 AI의 기초 단계에 더 적합한지 판단하는 데 초점을 두었다.",
        size=10,
    )
    page_break(doc)


def add_summary(doc: Document) -> None:
    heading(doc, "요 약")
    paragraph(
        doc,
        "본 프로젝트는 C. elegans(예쁜꼬마선충) 영상에서 Adult worm, Egg-small object, Larva-L1을 자동으로 찾고 추적하기 위한 기초 모델을 만드는 데서 출발하였다. "
        "C. elegans는 크기가 작고 투명하며 생애 주기가 짧아 유전학, 발생생물학, 신경과학, 노화 연구에서 널리 사용되는 모델 생물이다. "
        "하지만 많은 개체를 장시간 관찰할수록 사람이 직접 개체 수와 위치, 성장 단계를 확인하는 작업은 느리고 주관적이므로, 영상 기반 AI 검출과 추적이 필요하다.",
    )
    paragraph(
        doc,
        "실험에서는 BIO AI 창업 프로젝트에서 수집한 C. elegans 원본 영상과 수작업 마스크를 대상으로 U-Net 모델을 학습시켰다. "
        "수작업 시맨틱 마스크를 그대로 사용했을 때와 동일한 마스크를 Left Top, Right Bottom 형식의 bounding box 라벨로 변환해 사용했을 때의 차이를 비교하였다. "
        "전체 데이터는 원본 30장과 대응 마스크 30장으로 구성되어 있으며, 시간 순서를 유지한 상태로 학습 21장, 검증 4장, 테스트 5장으로 나누었다.",
    )
    paragraph(
        doc,
        "데이터를 먼저 확인해 보니 배경 픽셀이 전체의 99.205%를 차지했고, Adult worm은 0.620%, Egg는 0.116%, Larva-L1은 0.059%에 불과했다. "
        "따라서 단순 pixel accuracy만으로 모델 성능을 판단하면 실제 전경 객체 성능을 과대평가할 위험이 있었다. "
        "보고서에서는 Dice, IoU, foreground mIoU, detection F1, 라벨별 객체 수와 bbox 팽창률을 함께 사용하여 비교하였다.",
    )
    paragraph(
        doc,
        "테스트 결과 시맨틱 마스크 학습 U-Net은 foreground mIoU 0.526, foreground mean Dice 0.588을 보였고, bbox 라벨 학습 U-Net은 foreground mIoU 0.263, Dice 0.380으로 낮게 나타났다. "
        "반면 bbox 방식은 객체 위치를 넓게 덮는 성향 때문에 detection F1 기준에서는 0.577로 시맨틱 방식의 0.530보다 약간 높았다. "
        "즉, 객체의 정확한 경계와 면적을 알고 싶은 경우에는 시맨틱 마스크가 유리하고, 빠르게 후보 위치를 찾는 목적이라면 bbox 방식도 보조적으로 활용할 여지가 있다.",
    )
    paragraph(
        doc,
        "과적합 여부는 학습 손실과 검증 손실 곡선, best epoch, validation Dice 변화를 함께 확인하였다. "
        "두 모델 모두 검증 손실이 학습 손실보다 급격히 나빠지는 패턴은 확인되지 않았고, best epoch도 마지막 구간에 위치하여 강한 과적합 신호는 없었다. "
        "다만 검증 데이터가 4장으로 매우 작기 때문에, 과적합이 없다고 단정하기보다는 현재 실험 범위에서는 뚜렷한 징후가 없었다고 해석하는 것이 타당하다.",
    )
    add_table(
        doc,
        ["항목", "주요 결과"],
        [
            ["전체 데이터", "원본-마스크 쌍 30개"],
            ["데이터 분할", "학습 21개, 검증 4개, 테스트 5개"],
            ["시맨틱 U-Net", "테스트 foreground mIoU 0.526, mean Dice 0.588"],
            ["bbox U-Net", "테스트 foreground mIoU 0.263, mean Dice 0.380"],
            ["핵심 문제", "극심한 배경 편중, L1 라벨 부족, 작은 객체의 경계 손실, bbox 팽창"],
            ["개선 방향", "class-balanced loss, foreground crop sampling, 작은 객체 증강, 라벨 검수 및 데이터 추가"],
        ],
        widths=[4.0, 11.5],
    )
    page_break(doc)


def add_toc(doc: Document) -> None:
    heading(doc, "목 차")
    rows = [
        ["1", "서론", "C. elegans 연구 배경, 추적 AI 필요성, 목표, 기대 효과"],
        ["2", "배경 지식 및 관련 연구", "시맨틱 세그멘테이션, U-Net, bbox 라벨링, 평가 지표"],
        ["3", "추진 내용", "데이터 구성, bbox 변환, 학습 설정, 이슈 대응"],
        ["4", "실험 결과", "분할 현황, 클래스 분포, 정량 성능, 정성 결과, 과적합 분석"],
        ["5", "논의", "라벨링 방식별 장단점과 실제 적용 관점"],
        ["6", "결론", "요약, 한계, 향후 연구"],
        ["7", "참고문헌 및 부록", "재현 정보, 생성 데이터 목록"],
    ]
    add_table(doc, ["번호", "장", "내용"], rows, widths=[1.6, 4.8, 9.1])
    paragraph(
        doc,
        "보고서의 구성은 원래 최종보고서 양식의 큰 흐름인 서론, 배경 지식, 추진 내용, 결과, 결론을 유지하였다. "
        "각 장에는 발표 자료에서 사용한 그래프를 다시 배치했고, 발표에서는 짧게 지나가기 쉬운 해석과 한계를 본문에 조금 더 자세히 적었다.",
    )
    callout(
        doc,
        "작성 원칙",
        "좋은 수치만 강조하기보다는 데이터셋이 가진 약점과 그로 인해 모델이 실제로 어떤 오류를 만들었는지 함께 기록하였다. "
        "작은 데이터셋 실험에서는 이 부분이 모델 성능보다 더 중요한 판단 근거가 될 수 있기 때문이다.",
    )
    page_break(doc)


def add_intro(doc: Document) -> None:
    heading(doc, "1. 서론")
    heading(doc, "1.1 연구 배경", 2)
    paragraph(
        doc,
        "BIO AI 창업 프로젝트의 기본 아이디어는 C. elegans 영상에서 관찰 대상을 자동으로 찾아내고, 사람이 반복적으로 수행하던 계수와 분류 작업을 줄이는 데 있다. "
        "C. elegans는 실험실에서 많이 사용하는 모델 생물이지만, 실제 영상에서는 성체가 길고 휘어진 형태로 나타나며 알과 L1 유충은 매우 작게 보인다. "
        "또한 배경 질감, 조명, 초점, 개체 겹침에 따라 객체 경계가 흐려지기 때문에 단순 임계값 처리나 색상 기반 분리만으로는 안정적인 결과를 얻기 어렵다.",
    )
    paragraph(
        doc,
        "이번 실험의 원본 자료는 C. elegans 프레임 이미지와 그에 대응하는 컬러 마스크로 구성되어 있다. "
        "마스크에는 배경, Adult worm, Egg-small object, Larva-L1이 서로 다른 색상으로 표시되어 있으며, 이는 성장 단계와 객체 유형을 구분하기 위한 최소 단위의 라벨이다. "
        "처음에는 마스크를 그대로 이용한 시맨틱 세그멘테이션이 가장 자연스러운 접근으로 보였지만, 실제 현장에서는 라벨링 시간을 줄이기 위해 bounding box 방식도 자주 검토된다. "
        "따라서 같은 데이터를 두 방식으로 학습시켜 보면서, C. elegans 추적 AI에서 어떤 라벨링 방식이 더 적합한지 확인할 필요가 있었다.",
    )
    paragraph(
        doc,
        "특히 이 데이터셋에서는 전경 객체가 배경에 비해 매우 작다. 전체 픽셀 중 배경이 99% 이상이므로, 모델이 대부분의 픽셀을 배경으로 맞혀도 accuracy는 높게 보인다. "
        "또한 라벨별 객체 수와 면적이 균형을 이루지 않아 작은 객체나 희귀 클래스가 학습에서 쉽게 밀릴 수 있다. "
        "이 보고서는 이러한 문제를 정량적으로 드러내고, 보정이 필요한 지점을 실험 결과와 연결하여 설명하는 것을 목표로 한다.",
    )
    heading(doc, "1.2 C. elegans를 연구 대상으로 선택한 이유", 2)
    paragraph(
        doc,
        "C. elegans는 길이가 약 1 mm 정도인 작은 선충으로, 현미경 영상에서 개체 전체를 비교적 쉽게 관찰할 수 있다. "
        "몸이 투명하고 생애 주기가 짧으며, 배양과 관찰이 비교적 간단하다는 점 때문에 실험실에서 반복 실험을 설계하기 좋다. "
        "또한 발생 과정, 신경계, 행동 반응, 노화, 약물 반응을 작은 생물 안에서 함께 관찰할 수 있어 생명과학 연구에서 대표적인 모델 생물로 사용된다.",
    )
    paragraph(
        doc,
        "C. elegans가 중요한 이유는 단순히 작고 다루기 쉽기 때문만은 아니다. 성체 hermaphrodite의 체세포 수와 신경세포 수가 잘 알려져 있고, 신경계가 302개 뉴런 수준으로 비교적 단순하면서도 실제 행동을 만들어 낸다. "
        "따라서 움직임, 산란, 성장 단계 변화, 자극 반응 같은 현상을 정량화하면 유전자 변이, 약물 처리, 환경 변화가 생물의 행동과 발달에 어떤 영향을 주는지 분석할 수 있다. "
        "이처럼 C. elegans는 생물학적으로 해석 가능한 실험 대상이면서도 영상 데이터로 자동화하기 좋은 형태를 가지고 있다.",
    )
    add_table(
        doc,
        ["특징", "C. elegans 연구에서의 의미", "AI 영상 분석과의 연결"],
        [
            ["작은 크기와 투명한 몸", "현미경으로 전체 개체와 내부 구조 관찰이 쉬움", "원본 영상에서 객체 윤곽과 위치를 자동 검출하기 적합"],
            ["짧은 생애 주기", "알, 유충, 성체 단계 변화를 빠르게 관찰 가능", "시간에 따른 성장 단계 추적과 개체 수 변화 분석 가능"],
            ["잘 알려진 신경계", "302개 뉴런 수준에서 행동과 신경 회로를 연결해 해석 가능", "움직임 패턴을 정량화하면 행동 표현형 분석에 활용 가능"],
            ["대량 배양 가능", "많은 개체를 같은 조건에서 반복 실험 가능", "수작업 계수 대신 자동 검출/추적으로 고처리량 분석 가능"],
        ],
        widths=[3.2, 6.1, 6.1],
    )

    heading(doc, "1.3 C. elegans 추적 AI를 만들려는 이유", 2)
    paragraph(
        doc,
        "C. elegans 실험은 한두 마리만 관찰하는 경우보다 여러 개체를 같은 plate나 frame 안에서 반복적으로 관찰하는 경우가 많다. "
        "이때 사람이 직접 Adult, Egg, L1을 세고 위치를 확인하면 시간이 많이 걸리고, 관찰자에 따라 판단 기준이 달라질 수 있다. "
        "특히 영상이 길어지거나 프레임 수가 많아지면 수작업 분석은 연구 속도의 병목이 된다.",
    )
    paragraph(
        doc,
        "추적 AI의 목적은 단순히 이미지를 예쁘게 분할하는 것이 아니라, 생물 실험에서 반복적으로 필요한 정보를 자동으로 꺼내는 것이다. "
        "예를 들어 특정 처리 조건에서 성체의 이동량이 줄어드는지, 알의 수가 달라지는지, L1 유충이 어느 시점에 나타나는지, 개체가 서로 겹치거나 배경과 섞이는 상황에서도 안정적으로 위치를 찾을 수 있는지를 확인해야 한다. "
        "이런 정보를 얻기 위해서는 먼저 각 프레임에서 개체 영역을 정확히 찾는 segmentation 단계가 필요하고, 그 다음 프레임 간 동일 개체를 연결하는 tracking 단계로 확장된다.",
    )
    paragraph(
        doc,
        "이번 보고서의 U-Net 실험은 완성된 추적 시스템 전체가 아니라 그 앞단에 해당하는 '객체를 정확히 찾는 문제'를 검증한 것이다. "
        "시맨틱 마스크와 bbox 라벨을 비교한 이유도 여기에 있다. 정밀한 경계가 필요한 생물학적 면적 분석에는 시맨틱 마스크가 유리하지만, 빠른 후보 위치 검출에는 bbox 방식이 보조적으로 도움이 될 수 있다. "
        "따라서 본 프로젝트는 C. elegans 추적 AI를 만들기 위한 라벨링 정책과 모델 학습 방향을 정하는 기초 실험으로 볼 수 있다.",
    )
    add_table(
        doc,
        ["수작업 분석의 한계", "AI 추적이 제공할 수 있는 기능", "본 실험과의 연결"],
        [
            ["개체 수가 많아지면 계수 시간이 급증", "프레임별 Adult, Egg, L1 자동 검출", "마스크 기반 multi-class segmentation"],
            ["관찰자마다 경계 판단이 달라짐", "동일 기준으로 mask와 bbox 생성", "시맨틱 라벨과 bbox 라벨의 성능 비교"],
            ["작은 유충과 알을 놓치기 쉬움", "희귀/소형 객체를 별도 class로 관리", "L1과 Egg의 IoU, Dice를 분리 평가"],
            ["장시간 영상 분석이 어렵고 반복성이 낮음", "프레임 단위 결과를 누적해 추적/통계화", "추후 tracking으로 확장 가능한 객체 검출 기반 마련"],
        ],
        widths=[4.6, 5.3, 5.5],
    )

    heading(doc, "1.4 연구 목표", 2)
    bullet(doc, "원본 이미지와 마스크 30쌍을 정리하고, 학습/검증/테스트 데이터 수를 명확히 기록한다.")
    bullet(doc, "U-Net을 이용해 시맨틱 마스크 라벨과 bbox 변환 라벨을 각각 학습시킨 뒤 동일한 테스트 데이터에서 비교한다.")
    bullet(doc, "전체 accuracy가 아니라 foreground mIoU, Dice, class별 IoU, detection F1을 함께 사용하여 라벨링 방식별 장단점을 분석한다.")
    bullet(doc, "학습 곡선과 검증 곡선을 이용해 과적합 여부를 판단하고, 작은 데이터셋에서 남는 위험을 별도로 정리한다.")
    bullet(doc, "BIO AI 창업 프로젝트 관점에서 실제 서비스 또는 후속 실험에 반영할 보정 방안을 제시한다.")
    page_break(doc)

    heading(doc, "1.5 기대 효과", 2)
    paragraph(
        doc,
        "본 프로젝트의 결과는 모델을 한 번 학습시켰다는 데서 끝나지 않는다. "
        "어떤 라벨 방식이 어느 평가 지표에서 강점을 보이는지 확인하면, 이후 데이터 라벨링 비용과 모델 목표를 함께 고려한 의사결정을 할 수 있다. "
        "예를 들어 연구자가 객체의 정확한 면적이나 경계를 분석해야 한다면 시맨틱 마스크가 필요하고, 빠른 검출 후보를 만들기 위한 초기 필터라면 bbox 방식도 사용할 수 있다.",
    )
    paragraph(
        doc,
        "또한 데이터셋의 불균형과 작은 객체 문제를 수치로 보여주면, 단순히 '모델이 잘 안 된다'는 표현보다 개선 방향을 훨씬 구체적으로 잡을 수 있다. "
        "어떤 클래스가 부족한지, 어떤 클래스가 bbox로 바뀔 때 면적이 과도하게 커지는지, 그리고 어떤 지표가 실제 성능을 잘 반영하는지 확인할 수 있기 때문이다. "
        "이 점은 창업 프로젝트에서 데이터 추가 수집, 라벨링 정책, 사용자에게 보여줄 결과 화면을 정할 때 실질적인 기준이 된다.",
    )
    callout(
        doc,
        "핵심 관찰",
        "이번 실험에서는 시맨틱 방식이 경계 품질에서 우세했고, bbox 방식은 위치를 넓게 잡는 특성 때문에 검출 관점에서만 일부 장점이 있었다. "
        "따라서 두 방식은 단순히 우열 관계라기보다 목적이 다른 라벨 정책으로 보는 것이 적절하다.",
    )
    page_break(doc)


def add_background(doc: Document) -> None:
    heading(doc, "2. 배경 지식 및 관련 연구")
    heading(doc, "2.1 C. elegans 영상 추적의 의미", 2)
    paragraph(
        doc,
        "C. elegans 영상 분석에서 추적은 개체의 위치를 찾는 작업을 넘어 생물학적 현상을 수치화하는 과정이다. "
        "성체의 이동 경로, 몸의 굽힘 정도, 산란 이후 알의 분포, L1 유충의 출현 시점처럼 사람이 눈으로도 볼 수 있는 현상을 정량 데이터로 바꾸면 조건별 비교가 가능해진다. "
        "예를 들어 약물 처리군과 대조군의 이동량 차이, 특정 배양 조건에서 성장 단계가 지연되는지 여부, 개체 밀도가 높아졌을 때 행동이 어떻게 변하는지 등을 통계적으로 분석할 수 있다.",
    )
    paragraph(
        doc,
        "하지만 추적은 segmentation보다 한 단계 더 어렵다. 먼저 각 프레임에서 어떤 픽셀이 Adult, Egg, L1에 해당하는지 찾아야 하고, 이후 시간 순서에 따라 같은 개체를 연결해야 한다. "
        "따라서 추적 AI의 출발점은 안정적인 객체 분할이다. 본 보고서가 U-Net 기반 마스크 학습과 bbox 학습을 비교한 이유도 여기에 있다. "
        "분할 단계가 불안정하면 이후 tracking 단계에서 개체 ID가 끊기거나, 작은 유충이 누락되거나, 배경 노이즈가 개체로 잘못 연결될 수 있다.",
    )
    callout(
        doc,
        "프로젝트 관점",
        "이번 실험은 C. elegans 전체 추적 시스템 중 첫 단계인 객체 검출/분할 성능을 검증한 것이다. 좋은 추적 AI를 만들려면 먼저 frame 단위에서 개체 위치와 class를 안정적으로 찾아야 한다.",
    )

    heading(doc, "2.2 시맨틱 세그멘테이션", 2)
    paragraph(
        doc,
        "시맨틱 세그멘테이션은 이미지의 각 픽셀에 의미 있는 클래스를 부여하는 작업이다. "
        "본 프로젝트에서는 배경을 제외하고 Adult worm, Egg-small object, Larva-L1을 구분해야 하므로, 단순 객체 존재 여부가 아니라 픽셀 단위의 위치와 형태가 중요하다. "
        "시맨틱 마스크는 객체의 실제 모양을 직접 학습 신호로 제공한다는 장점이 있지만, 라벨링 시간이 오래 걸리고 작은 객체의 경계 품질에 따라 성능 변동이 생길 수 있다.",
    )
    paragraph(
        doc,
        "생물 영상에서는 배경과 객체의 색이 완전히 분리되지 않는 경우가 많고, 객체가 서로 겹치거나 흐리게 보이는 경우도 있다. "
        "이런 상황에서 픽셀 단위 라벨은 모델에게 가장 자세한 정보를 주지만, 동시에 사람이 만든 마스크의 오차도 그대로 학습될 수 있다. "
        "따라서 마스크 기반 학습 결과를 해석할 때는 결과 이미지뿐 아니라 라벨 분포와 confusion matrix도 함께 보아야 한다.",
    )
    heading(doc, "2.3 U-Net 구조", 2)
    paragraph(
        doc,
        "U-Net은 encoder-decoder 구조와 skip connection을 이용하는 대표적인 의료·생물 영상 분할 모델이다. "
        "encoder는 이미지의 큰 문맥을 추출하고, decoder는 다시 원래 해상도에 가까운 segmentation map을 복원한다. "
        "skip connection은 낮은 단계의 공간 정보를 decoder로 전달하여 작은 객체의 위치를 잃지 않도록 돕는다.",
    )
    paragraph(
        doc,
        "이번 실험에서는 데이터 수가 30장으로 적기 때문에 대형 모델을 쓰기보다 기본 U-Net을 사용하는 것이 적절하다고 판단했다. "
        "모델이 지나치게 복잡하면 학습 데이터에만 맞는 패턴을 외울 위험이 커지고, 반대로 너무 단순하면 작은 객체와 얇은 경계를 제대로 복원하지 못한다. "
        "따라서 모델 구조보다 라벨 방식과 데이터 특성이 결과에 어떤 영향을 주는지 보는 데 실험의 초점을 두었다.",
    )
    page_break(doc)

    heading(doc, "2.4 Bounding Box 라벨링", 2)
    paragraph(
        doc,
        "Bounding box 라벨링은 객체를 포함하는 사각형의 좌상단 좌표와 우하단 좌표를 기록하는 방식이다. "
        "본 프로젝트에서는 마스크의 connected component를 추출한 뒤 각 객체에 대해 x_min, y_min, x_max, y_max를 계산하여 Left Top, Right Bottom 형식의 라벨로 변환하였다. "
        "bbox는 사람이 빠르게 라벨링할 수 있고 객체 위치를 직관적으로 표현할 수 있지만, 객체가 길쭉하거나 굽어 있는 경우 사각형 안에 실제 객체가 아닌 배경도 함께 포함된다.",
    )
    paragraph(
        doc,
        "이 보고서에서 bbox 학습은 별도의 object detection 모델을 훈련한 것이 아니라, bbox를 다시 raster mask 형태로 채운 뒤 U-Net의 segmentation label로 사용한 방식이다. "
        "이렇게 하면 같은 U-Net 구조에서 마스크 라벨과 bbox 라벨을 비교할 수 있다. "
        "다만 bbox 라벨은 처음부터 실제 경계와 다르므로, 성능을 해석할 때 '모델이 틀렸다'와 '라벨 자체가 거칠다'를 구분해야 한다.",
    )
    heading(doc, "2.5 평가 지표", 2)
    paragraph(
        doc,
        "Pixel accuracy는 전체 픽셀 중 맞힌 비율을 의미한다. 하지만 본 데이터셋처럼 배경 비율이 압도적으로 높으면 모델이 전경을 놓쳐도 accuracy가 높게 유지될 수 있다. "
        "따라서 segmentation 성능을 볼 때는 Intersection over Union(IoU), Dice coefficient, foreground mean IoU를 함께 확인했다. "
        "IoU는 예측 영역과 정답 영역의 겹침 비율이고, Dice는 두 영역의 조화 평균적 유사도를 나타낸다.",
    )
    paragraph(
        doc,
        "Detection F1은 픽셀 경계보다 객체 단위로 맞췄는지를 보기 위한 보조 지표로 사용했다. "
        "예측 mask에서 connected component를 찾아 정답 객체와 IoU@0.5 기준으로 매칭하고, precision과 recall의 조화 평균을 계산했다. "
        "이 지표는 bbox 방식처럼 경계가 조금 거칠더라도 객체 위치를 잡는 데 성공하면 비교적 높게 나올 수 있다.",
    )
    page_break(doc)

    heading(doc, "2.6 데이터 불균형과 작은 객체 문제", 2)
    paragraph(
        doc,
        "BIO AI 창업 프로젝트에서 가장 먼저 고려해야 할 문제는 라벨별 데이터 양이 균형적이지 않다는 점이다. "
        "Adult worm은 픽셀 면적은 상대적으로 크지만 객체 수가 많지는 않고, Egg는 객체 수가 많지만 각각의 면적이 매우 작다. "
        "Larva-L1은 전체 픽셀 비율과 객체 수 모두 적어, 일반적인 loss만 사용하면 학습 과정에서 쉽게 배경 또는 다른 클래스에 밀릴 수 있다.",
    )
    paragraph(
        doc,
        "작은 객체는 해상도 축소 과정에서도 손실되기 쉽다. 원본은 1024 x 1024이지만 학습과 평가에서는 계산량을 줄이기 위해 384 크기로 조정하였다. "
        "이때 몇 픽셀에 불과한 객체는 형태 정보가 줄어들 수 있고, 특히 L1처럼 길이가 짧거나 경계가 얇은 라벨은 model output에서 사라질 가능성이 있다. "
        "따라서 향후에는 전체 이미지를 동일하게 줄이는 방법보다 객체 주변 crop을 더 자주 샘플링하는 전략이 필요하다.",
    )
    callout(
        doc,
        "해석상 주의",
        "Accuracy가 99%에 가까운 결과는 보기에는 좋아 보이지만, 이 데이터에서는 배경을 맞힌 비율의 영향이 크다. "
        "따라서 보고서의 결론은 foreground IoU와 Dice를 중심으로 작성하였다.",
    )
    page_break(doc)


def add_methods(doc: Document) -> None:
    heading(doc, "3. 추진 내용")
    heading(doc, "3.1 팀 구성 및 역할", 2)
    add_table(
        doc,
        ["이름", "역할", "수행 업무"],
        [
            ["이기원", "프로젝트 수행", "원본/마스크 자료 정리, bbox 변환, U-Net 학습, 정량 지표 산출, 그래프 제작, 최종보고서 작성"],
        ],
        widths=[3.0, 3.0, 9.6],
    )
    paragraph(
        doc,
        "팀원 정보는 현재 확보된 작성자 정보를 기준으로 정리하였다. 실제 제출 전 학교 양식에서 요구하는 학번, 지도교수, 공동 팀원 정보가 있다면 표지와 역할 표에 추가하면 된다. "
        "실험 자체는 동일한 파일 경로와 분석 결과를 기준으로 재현 가능하도록 구성하였다.",
    )
    heading(doc, "3.2 전체 시스템 구성", 2)
    paragraph(
        doc,
        "전체 파이프라인은 데이터 정리, 라벨 변환, 모델 학습, 성능 평가, 결과 시각화의 순서로 구성하였다. "
        "원본 프레임과 마스크를 같은 번호 기준으로 pairing한 뒤, 마스크 색상을 class id로 변환하였다. "
        "bbox 실험에서는 각 class id 영역을 connected component로 분리하고, 객체별 bounding box 좌표를 산출하였다.",
    )
    bullet(doc, "입력: 원본 frame 이미지 30장, 컬러 mask 이미지 30장")
    bullet(doc, "전처리: RGB mask 색상 기준 class id 변환, 이미지 크기 통일, train/validation/test split 생성")
    bullet(doc, "라벨 변환: 시맨틱 마스크 유지 또는 bbox 좌표를 채운 box mask 생성")
    bullet(doc, "학습: 동일한 U-Net 구조를 두 라벨 방식에 각각 적용")
    bullet(doc, "평가: pixel accuracy, IoU, Dice, precision, recall, detection F1, overfitting diagnosis")
    page_break(doc)

    heading(doc, "3.3 데이터 구성 및 분할 정책", 2)
    paragraph(
        doc,
        "데이터 수가 많지 않기 때문에 무작위 분할을 여러 번 반복하기보다는 파일 순서를 유지한 시간 순서 분할을 사용하였다. "
        "이는 가까운 프레임끼리 지나치게 섞여 train과 test가 비슷해지는 문제를 줄이기 위한 선택이다. "
        "다만 전체 수가 30장뿐이므로 validation과 test가 각각 4장, 5장으로 작다는 한계는 남는다.",
    )
    add_table(
        doc,
        ["구분", "프레임 범위", "개수", "비율", "사용 목적"],
        [
            ["Training", "frame_00000 ~ frame_00020", "21", "70.0%", "모델 파라미터 학습"],
            ["Validation", "frame_00021 ~ frame_00024", "4", "13.3%", "best epoch 선택 및 과적합 확인"],
            ["Test", "frame_00025 ~ frame_00029", "5", "16.7%", "최종 성능 산출"],
            ["Total", "frame_00000 ~ frame_00029", "30", "100.0%", "원본-마스크 쌍 전체"],
        ],
        widths=[3.0, 4.4, 2.0, 2.0, 4.2],
    )
    add_picture(doc, "split_distribution.png", width_cm=12.5, cap="그림 1. 학습/검증/테스트 데이터 분할 비율")
    page_break(doc)

    heading(doc, "3.4 라벨 정의와 색상 매핑", 2)
    paragraph(
        doc,
        "마스크 파일은 색상으로 라벨을 구분하는 방식이었다. 실험에서는 배경을 class 0으로 두고, 전경 라벨 세 개를 class 1부터 class 3까지 할당하였다. "
        "라벨 이름은 생물학적 의미와 마스크 색상을 함께 적어, 이후 그래프를 볼 때 어떤 객체가 어느 색에 해당하는지 혼동하지 않도록 했다.",
    )
    add_table(
        doc,
        ["Class ID", "라벨명", "마스크 색상", "분석상 의미"],
        [
            ["0", "Background", "Black", "배경 및 비객체 영역"],
            ["1", "Adult worm", "Red", "상대적으로 크고 길쭉한 성체 객체"],
            ["2", "Egg-small object", "Green", "작고 수가 많은 알 또는 소형 객체"],
            ["3", "Larva-L1", "Blue", "매우 작은 유충 객체, 희귀 클래스"],
        ],
        widths=[2.2, 4.2, 3.0, 6.2],
    )
    add_picture(doc, "sample_true_overlay.png", width_cm=14.2, cap="그림 2. 원본 영상 위에 수작업 시맨틱 마스크를 겹친 예시")
    paragraph(
        doc,
        "시맨틱 마스크는 객체의 실제 형태를 최대한 따라가지만, bbox 라벨은 같은 객체를 사각형으로 감싸기 때문에 배경이 포함된다. "
        "따라서 두 라벨 방식은 처음부터 모델에게 제공하는 정답의 정보량이 다르다.",
    )
    page_break(doc)

    heading(doc, "3.5 Bounding Box 변환 방법", 2)
    paragraph(
        doc,
        "bbox 변환은 각 전경 클래스마다 connected component를 찾고, component의 최소 x, 최소 y, 최대 x, 최대 y를 계산하는 방식으로 진행하였다. "
        "이 좌표가 곧 Left Top, Right Bottom 형식의 라벨이다. 이후 같은 U-Net 학습을 위해 해당 bbox 영역을 class id로 채운 raster mask를 만들었다.",
    )
    add_table(
        doc,
        ["항목", "내용"],
        [
            ["입력 라벨", "픽셀 단위 시맨틱 마스크"],
            ["객체 분리", "클래스별 connected component 추출"],
            ["좌표 형식", "left_top=(x_min, y_min), right_bottom=(x_max, y_max)"],
            ["생성 라벨", "bbox 내부를 해당 class id로 채운 box mask"],
            ["총 bbox 수", f"{dataset['bbox_count']}개"],
        ],
        widths=[4.0, 11.4],
    )
    add_picture(doc, "sample_bbox_boxes_overlay.png", width_cm=14.2, cap="그림 3. 마스크에서 변환한 bbox를 원본 영상에 표시한 예시")
    paragraph(
        doc,
        "이 방식은 실제 detection 데이터셋을 만드는 절차와 비슷하지만, 본 실험에서는 모델 구조를 U-Net으로 고정하기 위해 bbox를 segmentation mask처럼 사용했다. "
        "그 결과 bbox 학습은 객체의 위치를 넓게 덮는 방향으로 학습되며, 정밀한 윤곽선 복원에는 불리할 수밖에 없다.",
    )
    page_break(doc)

    heading(doc, "3.6 모델 학습 설정", 2)
    paragraph(
        doc,
        "시맨틱 마스크와 bbox mask는 같은 U-Net 구조, 같은 데이터 분할, 같은 평가 절차로 학습하였다. "
        "차이를 만드는 요소를 라벨 방식으로 제한하기 위해 모델과 실험 조건을 되도록 맞추었다. "
        "입력 영상은 원본 1024 x 1024에서 학습·평가용 384 크기로 조정하였다.",
    )
    add_table(
        doc,
        ["구분", "설정"],
        [
            ["모델", "U-Net 기반 multi-class segmentation"],
            ["입력 크기", "1024 x 1024 원본, 학습/평가 시 384 크기 사용"],
            ["클래스 수", "4개: Background, Adult worm, Egg-small object, Larva-L1"],
            ["라벨 방식 A", "수작업 시맨틱 마스크"],
            ["라벨 방식 B", "시맨틱 마스크에서 변환한 bounding box mask"],
            ["평가 데이터", "두 방식 모두 동일한 test 5장 사용"],
            ["과적합 확인", "train/validation loss gap, best epoch, validation Dice curve"],
        ],
        widths=[4.0, 11.4],
    )
    callout(
        doc,
        "실험 통제",
        "데이터 수가 작기 때문에 모델을 바꿔 여러 결과를 만드는 것보다, 같은 모델에서 라벨 방식만 바꾸는 비교가 더 해석하기 쉽다고 판단했다.",
    )
    page_break(doc)

    heading(doc, "3.7 이슈 및 대응", 2)
    add_table(
        doc,
        ["이슈", "관찰 내용", "대응 및 해석"],
        [
            ["배경 편중", "배경 픽셀이 99% 이상", "accuracy 대신 foreground mIoU와 Dice 중심으로 해석"],
            ["작은 객체", "Egg와 L1의 픽셀 면적이 매우 작음", "객체 수, 면적 histogram, class별 IoU를 별도로 산출"],
            ["희귀 라벨", "L1은 픽셀 비율 0.059%", "데이터 추가와 class-balanced loss 필요"],
            ["bbox 팽창", "길쭉한 객체에서 bbox가 실제 mask보다 크게 잡힘", "bbox tightness와 inflation 지표 산출"],
            ["검증 데이터 부족", "validation 4장", "과적합 판단을 보수적으로 표현하고 후속 k-fold 검증 제안"],
        ],
        widths=[2.6, 5.0, 7.8],
    )
    paragraph(
        doc,
        "실제 프로젝트에서는 이러한 이슈를 미리 정리해 두는 것이 중요하다. "
        "모델 결과가 기대보다 낮게 나왔을 때 원인을 모델 구조에서만 찾으면 데이터 라벨링 정책이나 평가 방식의 문제를 놓치기 쉽다. "
        "이번 분석에서는 데이터 자체의 특성을 먼저 숫자로 확인한 다음, 학습 결과를 해석하는 순서로 진행하였다.",
    )
    heading(doc, "3.8 실험 재현 절차", 2)
    paragraph(
        doc,
        "실험 재현성은 보고서 신뢰도와 직접 연결된다. 이번 분석에서는 데이터 분할을 한 번 정한 뒤, "
        "시맨틱 마스크 학습과 bbox mask 학습이 같은 train, validation, test 프레임을 사용하도록 고정하였다. "
        "이렇게 해야 성능 차이가 데이터 분할 우연성보다 라벨링 방식의 차이에서 비롯되었다고 해석할 수 있다.",
    )
    add_table(
        doc,
        ["단계", "수행 내용", "산출물", "확인 포인트"],
        [
            ["1", "원본 이미지와 마스크 파일명 매칭", "30개 paired sample", "원본과 마스크가 같은 프레임인지 확인"],
            ["2", "마스크 색상을 class id로 변환", "4-class semantic mask", "RGB 색상 오차와 배경 처리 확인"],
            ["3", "연결 성분 기반 bbox 좌표 산출", "left-top/right-bottom CSV", "작은 객체가 누락되지 않았는지 확인"],
            ["4", "시맨틱 라벨과 bbox 라벨을 각각 학습", "두 개의 U-Net 모델", "동일 split, 동일 평가 조건 유지"],
            ["5", "test set에서 정량/정성 결과 생성", "CSV, 그래프, overlay 이미지", "accuracy만 보지 않고 foreground 지표 확인"],
        ],
        widths=[1.3, 4.2, 4.0, 5.9],
    )
    paragraph(
        doc,
        "이 과정에서 가장 신경 쓴 부분은 bbox 변환을 단순히 부가 자료로만 쓰지 않고, 실제 학습 라벨로 사용할 수 있도록 raster mask 형태로 다시 만드는 것이었다. "
        "그 결과 두 실험은 같은 네트워크 구조 안에서 라벨 표현 방식만 바꾼 비교가 되었고, 교수님이 질문할 수 있는 '모델이 달라서 생긴 차이인지, 라벨이 달라서 생긴 차이인지'에 대해 비교적 명확하게 답할 수 있다.",
    )
    callout(
        doc,
        "재현성 관점의 장점",
        "split manifest, bbox annotation CSV, per-class metrics, overfitting diagnosis 파일을 모두 남겼기 때문에 후속 실험에서 loss나 augmentation만 바꾸어도 같은 test set 기준으로 다시 비교할 수 있다.",
    )
    page_break(doc)


def add_results(doc: Document) -> None:
    heading(doc, "4. 실험 결과")
    heading(doc, "4.1 클래스 픽셀 분포", 2)
    paragraph(
        doc,
        "전체 마스크 픽셀을 집계한 결과, 배경이 전체의 "
        f"{pct(dataset['class_pixel_ratios']['Background'], 3)}를 차지하였다. "
        f"Adult worm은 {pct(dataset['class_pixel_ratios']['Adult worm / Red'], 3)}, "
        f"Egg-small object는 {pct(dataset['class_pixel_ratios']['Egg-small object / Green'], 3)}, "
        f"Larva-L1은 {pct(dataset['class_pixel_ratios']['Larva-L1 / Blue'], 3)}였다. "
        "이 수치는 모델이 배경 위주로 예측해도 높은 accuracy를 얻을 수 있음을 보여준다.",
    )
    add_table(
        doc,
        ["라벨", "픽셀 수", "전체 비율", "해석"],
        [
            ["Background", f"{dataset['class_pixel_counts']['Background']:,}", pct(dataset["class_pixel_ratios"]["Background"], 3), "절대 다수 클래스"],
            ["Adult worm", f"{dataset['class_pixel_counts']['Adult worm / Red']:,}", pct(dataset["class_pixel_ratios"]["Adult worm / Red"], 3), "면적은 가장 큰 전경 클래스"],
            ["Egg-small object", f"{dataset['class_pixel_counts']['Egg-small object / Green']:,}", pct(dataset["class_pixel_ratios"]["Egg-small object / Green"], 3), "작고 많은 객체"],
            ["Larva-L1", f"{dataset['class_pixel_counts']['Larva-L1 / Blue']:,}", pct(dataset["class_pixel_ratios"]["Larva-L1 / Blue"], 3), "가장 희귀한 전경 클래스"],
        ],
        widths=[3.5, 3.0, 2.6, 6.3],
    )
    add_picture(doc, "class_pixel_distribution.png", width_cm=14.2, cap="그림 4. 전체 데이터 기준 클래스별 픽셀 분포")
    page_break(doc)

    heading(doc, "4.2 객체 수와 크기 분포", 2)
    paragraph(
        doc,
        f"객체 수 기준으로는 Egg-small object가 {dataset['class_object_counts']['Egg-small object / Green']}개로 가장 많았다. "
        f"Adult worm은 {dataset['class_object_counts']['Adult worm / Red']}개, Larva-L1은 {dataset['class_object_counts']['Larva-L1 / Blue']}개였다. "
        "픽셀 면적과 객체 수가 반드시 같은 의미를 갖지는 않는다는 점이 여기서 드러난다. "
        "Egg는 수가 많지만 각각이 작고, Adult worm은 수가 적어도 한 객체가 차지하는 면적이 크다.",
    )
    add_picture(doc, "object_counts_by_class.png", width_cm=13.2, cap="그림 5. 클래스별 객체 수")
    add_picture(doc, "object_size_histogram.png", width_cm=13.2, cap="그림 6. 객체 면적 분포 histogram")
    paragraph(
        doc,
        "작은 객체가 많다는 것은 모델이 전체 이미지를 한 번에 처리할 때 놓치는 객체가 생길 가능성이 높다는 뜻이다. "
        "특히 validation과 test에 포함된 작은 객체의 수가 적으면, 한두 개의 검출 실패가 class별 IoU를 크게 흔들 수 있다.",
    )
    page_break(doc)

    heading(doc, "4.3 프레임별 전경 면적 변화", 2)
    paragraph(
        doc,
        "프레임별 전경 면적 비율을 보면 데이터가 완전히 균일하지 않다. "
        "어떤 프레임은 전경이 상대적으로 많이 들어 있고, 어떤 프레임은 배경이 거의 대부분을 차지한다. "
        "이런 차이는 train/validation/test 분할에 따라 성능이 민감하게 달라질 수 있음을 의미한다.",
    )
    add_picture(doc, "per_frame_area_ratio.png", width_cm=15.4, cap="그림 7. 프레임별 클래스 면적 비율 변화")
    paragraph(
        doc,
        "시간 순서 분할은 실제 적용 상황에 가깝지만, 데이터가 30장으로 적은 상태에서는 특정 구간에 어떤 라벨이 몰려 있는지의 영향을 크게 받는다. "
        "따라서 최종 모델을 만들 때는 현재 분할 외에도 stratified split 또는 k-fold cross validation을 추가로 확인하는 것이 좋다.",
    )
    page_break(doc)

    heading(doc, "4.4 bbox 변환에 따른 정보 손실", 2)
    paragraph(
        doc,
        "bbox 변환에서 가장 중요한 지표는 tightness와 inflation이다. "
        "tightness는 bbox 내부에서 실제 mask가 차지하는 비율이고, inflation은 bbox 면적이 실제 mask 면적보다 몇 배 커졌는지를 의미한다. "
        "tightness가 낮고 inflation이 높으면 bbox 라벨이 많은 배경을 포함한다는 뜻이다.",
    )
    add_table(
        doc,
        ["라벨", "평균 tightness", "평균 inflation", "해석"],
        [
            ["Adult worm", num(dataset["bbox_tightness_mean"]["Adult worm / Red"], 3), f"{num(dataset['bbox_inflation_mean']['Adult worm / Red'], 2)}x", "길쭉한 형태 때문에 bbox 팽창이 큼"],
            ["Egg-small object", num(dataset["bbox_tightness_mean"]["Egg-small object / Green"], 3), f"{num(dataset['bbox_inflation_mean']['Egg-small object / Green'], 2)}x", "상대적으로 원형에 가까워 정보 손실이 작음"],
            ["Larva-L1", num(dataset["bbox_tightness_mean"]["Larva-L1 / Blue"], 3), f"{num(dataset['bbox_inflation_mean']['Larva-L1 / Blue'], 2)}x", "작고 얇아 bbox가 배경을 많이 포함"],
        ],
        widths=[3.2, 3.0, 3.0, 6.2],
    )
    add_picture(doc, "bbox_tightness_by_class.png", width_cm=13.2, cap="그림 8. 클래스별 bbox tightness")
    add_picture(doc, "bbox_inflation.png", width_cm=13.2, cap="그림 9. 클래스별 bbox inflation")
    page_break(doc)

    heading(doc, "4.5 bbox 라벨의 상한 성능 해석", 2)
    paragraph(
        doc,
        "bbox 라벨은 실제 시맨틱 마스크를 사각형으로 바꾼 것이므로, 모델이 bbox 라벨을 완벽하게 예측하더라도 실제 마스크 기준 성능에는 한계가 있다. "
        "이를 확인하기 위해 bbox label 자체를 정답 시맨틱 마스크와 비교한 upper bound를 계산하였다. "
        f"테스트 기준 bbox label upper bound의 foreground mIoU는 {num(upper_test['foreground_mIoU'], 3)}, mean Dice는 {num(upper_test['foreground_mean_dice'], 3)}였다.",
    )
    paragraph(
        doc,
        "이 값은 bbox 방식의 구조적 한계를 보여준다. "
        "모델이 아무리 학습을 잘해도 bbox 라벨이 포함하는 배경 영역 때문에 실제 경계 기준 점수는 일정 수준 이상 올라가기 어렵다. "
        "따라서 bbox 방식의 성능 저하는 학습 실패만이 아니라 라벨 표현 방식의 차이에서 발생한 부분도 크다.",
    )
    add_picture(doc, "confusion_bbox_mask.png", width_cm=12.5, cap="그림 10. bbox 라벨과 실제 마스크 기준 confusion matrix")
    callout(
        doc,
        "중요한 해석",
        "bbox 방식은 라벨링 시간을 줄이지만, 경계 정보를 버리는 비용을 지불한다. "
        "특히 Adult worm처럼 길고 굽은 객체는 사각형 라벨로 바꿀 때 배경 픽셀이 많이 섞인다.",
    )
    page_break(doc)

    heading(doc, "4.6 학습 손실과 과적합 진단", 2)
    paragraph(
        doc,
        "과적합은 학습 데이터에서는 손실이 계속 낮아지지만 검증 데이터에서는 손실이 증가하거나 Dice가 떨어지는 패턴으로 확인할 수 있다. "
        "이번 실험에서는 두 모델 모두 best epoch가 28로 마지막 구간에 위치했고, 최종 train/validation loss gap도 과도하게 벌어지지 않았다.",
    )
    add_table(
        doc,
        ["모델", "Best epoch", "최종 train loss", "최종 validation loss", "Val-Train gap", "진단"],
        [
            [
                "Semantic mask U-Net",
                str(overfit["semantic_mask"]["best_epoch"]),
                num(overfit["semantic_mask"]["final_train_loss"], 4),
                num(overfit["semantic_mask"]["final_validation_loss"], 4),
                num(overfit["semantic_mask"]["final_gap_validation_minus_train"], 4),
                "강한 과적합 신호 없음",
            ],
            [
                "BBox mask U-Net",
                str(overfit["bbox_mask"]["best_epoch"]),
                num(overfit["bbox_mask"]["final_train_loss"], 4),
                num(overfit["bbox_mask"]["final_validation_loss"], 4),
                num(overfit["bbox_mask"]["final_gap_validation_minus_train"], 4),
                "강한 과적합 신호 없음",
            ],
        ],
        widths=[3.5, 2.1, 2.7, 3.1, 2.4, 3.6],
    )
    add_picture(doc, "training_loss_curves.png", width_cm=15.2, cap="그림 11. 학습 및 검증 loss curve")
    page_break(doc)

    heading(doc, "4.7 Validation Dice 변화", 2)
    paragraph(
        doc,
        "Validation Dice 곡선은 모델이 검증 데이터에서 실제 전경을 얼마나 안정적으로 맞히는지 확인하기 위한 지표다. "
        "시맨틱 마스크 학습은 bbox 학습보다 전반적으로 높은 Dice를 보였고, 이는 경계 정보가 더 정확한 라벨에서 학습했기 때문으로 해석된다. "
        "반면 bbox 학습은 box 내부 배경까지 라벨로 포함하기 때문에 전경 영역의 정밀도가 떨어지는 경향이 있었다.",
    )
    add_picture(doc, "validation_dice_curves.png", width_cm=15.2, cap="그림 12. Validation Dice curve")
    paragraph(
        doc,
        "다만 validation 데이터가 4장뿐이므로 곡선이 안정적인 일반화 성능을 완전히 보장하지는 않는다. "
        "추후 데이터가 늘어나면 validation set을 별도로 확장하거나 cross validation으로 같은 경향이 반복되는지 확인해야 한다.",
    )
    page_break(doc)

    heading(doc, "4.8 테스트 전체 성능 비교", 2)
    paragraph(
        doc,
        "테스트 데이터 5장에서 두 모델의 전체 지표를 비교하였다. "
        "Pixel accuracy는 두 모델 모두 높지만, 이는 배경 비율의 영향이 크다. "
        "실제 전경 기준으로 보면 시맨틱 마스크 학습이 bbox 학습보다 foreground mIoU와 mean Dice에서 뚜렷하게 높았다.",
    )
    add_table(
        doc,
        ["지표", "Semantic mask U-Net", "BBox mask U-Net", "차이 해석"],
        [
            ["Pixel accuracy", pct(semantic_test["pixel_accuracy"], 3), pct(bbox_test["pixel_accuracy"], 3), "둘 다 높지만 배경 영향이 큼"],
            ["Foreground mIoU", num(semantic_test["foreground_mIoU"], 3), num(bbox_test["foreground_mIoU"], 3), "시맨틱 방식이 약 2배 높음"],
            ["Foreground mean Dice", num(semantic_test["foreground_mean_dice"], 3), num(bbox_test["foreground_mean_dice"], 3), "경계 정보 보존 효과"],
            ["Foreground recall", num(semantic_test["foreground_mean_recall"], 3), num(bbox_test["foreground_mean_recall"], 3), "bbox 방식이 넓게 잡아 recall은 유사하거나 높음"],
            ["Foreground precision", num(semantic_test["foreground_mean_precision"], 3), num(bbox_test["foreground_mean_precision"], 3), "bbox 방식은 배경 포함으로 precision 저하"],
        ],
        widths=[3.3, 3.3, 3.3, 5.7],
    )
    add_picture(doc, "test_metric_comparison.png", width_cm=14.2, cap="그림 13. 테스트 주요 성능 지표 비교")
    page_break(doc)

    heading(doc, "4.9 클래스별 IoU와 Dice", 2)
    paragraph(
        doc,
        "클래스별로 보면 차이가 더 분명하다. Adult worm은 시맨틱 학습에서 IoU 0.833, Dice 0.909를 보였지만 bbox 학습에서는 IoU 0.227, Dice 0.371로 낮아졌다. "
        "Egg-small object는 bbox의 정보 손실이 상대적으로 작아 bbox 학습에서도 IoU 0.515를 기록했지만, 시맨틱 학습의 0.745에는 미치지 못했다. "
        "Larva-L1은 두 방식 모두 어려웠고, 특히 시맨틱 방식에서는 테스트 IoU가 0으로 나타났다.",
    )
    add_table(
        doc,
        ["Class", "Semantic IoU", "Semantic Dice", "BBox IoU", "BBox Dice", "해석"],
        [
            [
                row["class"],
                num(row["semantic_mask_iou"], 3),
                num(row["semantic_mask_dice"], 3),
                num(row["bbox_mask_iou"], 3),
                num(row["bbox_mask_dice"], 3),
                "작은/희귀 클래스일수록 불안정" if "Larva" in row["class"] else "시맨틱 방식 우세",
            ]
            for row in per_class_rows
        ],
        widths=[3.0, 2.4, 2.4, 2.3, 2.3, 3.0],
    )
    add_picture(doc, "per_class_iou.png", width_cm=14.2, cap="그림 14. 클래스별 테스트 IoU 비교")
    paragraph(
        doc,
        "L1 결과는 단순히 모델이 나쁘다는 결론으로 끝내기 어렵다. "
        "전체 픽셀 비율이 0.059%에 불과하고 크기가 작기 때문에, 학습 sampling과 loss 설계를 바꾸지 않으면 모델이 이 클래스를 충분히 학습하지 못할 가능성이 높다.",
    )
    page_break(doc)

    heading(doc, "4.10 Detection F1 비교", 2)
    semantic_det = next(r for r in detection_rows if r["model"] == "semantic_mask")
    bbox_det = next(r for r in detection_rows if r["model"] == "bbox_mask")
    paragraph(
        doc,
        "객체 단위 detection F1을 보면 bbox 학습이 평균 F1 "
        f"{num(bbox_det['mean_f1'], 3)}로, 시맨틱 학습의 {num(semantic_det['mean_f1'], 3)}보다 약간 높았다. "
        "이는 bbox 방식이 경계를 정확히 맞히지는 못하더라도 객체 위치를 넓게 덮어 recall을 확보하기 쉽기 때문이다. "
        "따라서 detection F1만 보면 bbox 방식이 유리해 보일 수 있지만, 경계 품질을 보는 IoU와 Dice에서는 반대 결과가 나온다.",
    )
    add_table(
        doc,
        ["모델", "Mean F1", "Precision", "Recall", "해석"],
        [
            ["Semantic mask", num(semantic_det["mean_f1"], 3), num(semantic_det["mean_precision"], 3), num(semantic_det["mean_recall"], 3), "경계 정확도 우세, 일부 작은 객체 누락"],
            ["BBox mask", num(bbox_det["mean_f1"], 3), num(bbox_det["mean_precision"], 3), num(bbox_det["mean_recall"], 3), "넓게 덮는 예측으로 객체 위치 검출에 유리"],
        ],
        widths=[3.4, 2.4, 2.4, 2.4, 4.8],
    )
    add_picture(doc, "bbox_detection_f1.png", width_cm=14.0, cap="그림 15. 객체 단위 detection F1 비교")
    page_break(doc)

    heading(doc, "4.11 정성 결과 비교", 2)
    paragraph(
        doc,
        "정성 결과를 보면 시맨틱 마스크 학습은 Adult worm과 Egg의 경계를 비교적 잘 따라간다. "
        "반면 bbox 학습은 객체 주변을 사각형 형태로 넓게 잡는 경향이 있고, 실제 객체가 없는 배경도 전경으로 포함되는 경우가 있다. "
        "이 차이는 정량 지표에서 foreground precision이 낮아진 이유와도 연결된다.",
    )
    add_picture(doc, "sample_semantic_prediction_overlay.png", width_cm=13.2, cap="그림 16. 시맨틱 마스크 학습 모델의 예측 overlay")
    add_picture(doc, "sample_bbox_prediction_overlay.png", width_cm=13.2, cap="그림 17. bbox mask 학습 모델의 예측 overlay")
    page_break(doc)

    heading(doc, "4.12 최종 비교 패널", 2)
    paragraph(
        doc,
        "아래 패널은 원본, 정답 마스크, 시맨틱 예측, bbox 예측을 한 번에 비교한 것이다. "
        "발표 자료에서는 이 그림이 가장 직관적인 결과였으며, 보고서에서도 라벨링 방식의 차이를 설명하기 위한 핵심 정성 자료로 사용하였다.",
    )
    add_picture(doc, "final_qualitative_2x2.png", width_cm=15.4, cap="그림 18. 원본, 정답, 시맨틱 예측, bbox 예측 최종 비교 패널")
    paragraph(
        doc,
        "시맨틱 방식은 실제 경계를 더 잘 따르지만 작은 L1 객체를 놓칠 수 있고, bbox 방식은 더 넓은 후보 영역을 만들지만 경계 해석에는 적합하지 않다. "
        "따라서 현장 적용에서는 두 결과를 목적에 따라 다르게 사용할 수 있다. 예를 들어 1차 후보 검출에는 bbox형 결과를 쓰고, 최종 면적 분석에는 시맨틱 결과를 쓰는 식의 단계적 구성이 가능하다.",
    )
    page_break(doc)

    heading(doc, "4.13 오류 분석", 2)
    paragraph(
        doc,
        "오류는 크게 세 가지로 나눌 수 있었다. 첫째, 작은 객체가 축소 과정에서 약해져 누락되는 경우가 있었다. "
        "둘째, 길쭉하거나 굽은 객체는 bbox 변환에서 실제보다 넓은 정답이 만들어져 precision이 낮아졌다. "
        "셋째, 데이터 수가 적어 특정 프레임의 조명이나 배경 질감 변화가 성능에 영향을 줄 수 있었다.",
    )
    add_picture(doc, "confusion_semantic_mask.png", width_cm=12.8, cap="그림 19. 시맨틱 U-Net 테스트 confusion matrix")
    paragraph(
        doc,
        "Confusion matrix에서도 배경이 차지하는 양이 매우 크기 때문에 전경 오류가 시각적으로 작게 보일 수 있다. "
        "보고서에서는 이 점을 보완하기 위해 class별 IoU와 Dice를 별도로 제시하였다.",
    )
    heading(doc, "4.14 종합 결과 해석", 2)
    paragraph(
        doc,
        "전체 결과를 종합하면, 이번 데이터셋에서 라벨링 방식의 차이는 단순한 성능 수치 차이가 아니라 학습 목표 자체의 차이로 볼 수 있다. "
        "시맨틱 마스크는 객체의 실제 형태를 학습시키므로 IoU와 Dice처럼 경계 품질을 보는 지표에서 강점을 보인다. "
        "반면 bbox mask는 객체를 사각형으로 넓게 덮는 라벨이기 때문에 실제 전경보다 큰 영역을 정답으로 학습하고, 이로 인해 precision이 낮아지는 대신 recall이나 객체 위치 검출에서는 일부 장점을 가질 수 있다.",
    )
    paragraph(
        doc,
        "특히 Adult worm 클래스에서 차이가 크게 나타난 이유는 객체 형태와 bbox 표현 방식이 잘 맞지 않았기 때문이다. "
        "Adult worm은 길고 굽은 형태가 많아 실제 mask 면적에 비해 bbox가 크게 팽창한다. "
        "그 결과 bbox 학습 모델은 객체 주변 배경까지 전경으로 예측하는 경향을 보였고, 테스트 IoU가 시맨틱 방식보다 크게 낮아졌다. "
        "Egg-small object는 상대적으로 작고 둥근 형태라 bbox와 실제 mask의 차이가 작아 bbox 방식에서도 비교적 높은 점수를 보였다.",
    )
    paragraph(
        doc,
        "Larva-L1 결과는 보고서에서 반드시 조심해서 설명해야 한다. 시맨틱 방식의 L1 IoU가 0으로 나온 것은 모델이 이 클래스를 안정적으로 잡지 못했다는 뜻이지만, "
        "동시에 L1 픽셀 비율이 0.059%밖에 되지 않는다는 데이터 조건도 함께 봐야 한다. "
        "즉 L1 성능은 단순한 모델 실패라기보다 데이터 부족, 작은 객체 크기, resize에 따른 정보 손실, class imbalance가 동시에 작용한 결과로 해석하는 것이 타당하다.",
    )
    add_table(
        doc,
        ["관찰 결과", "원인 해석", "보고서에서의 결론"],
        [
            ["Pixel accuracy는 두 모델 모두 높음", "배경 픽셀이 99% 이상이라 전체 정확도가 쉽게 높아짐", "핵심 지표로 사용하기에는 부족함"],
            ["시맨틱 방식의 foreground mIoU가 높음", "실제 경계와 면적 정보를 그대로 학습함", "정밀 분할 및 면적 분석에 적합"],
            ["bbox 방식의 detection F1이 약간 높음", "사각형 라벨이 객체 위치를 넓게 덮어 recall 확보에 유리함", "1차 후보 검출에는 활용 가능"],
            ["L1 성능이 낮음", "라벨 양과 픽셀 면적이 모두 부족하고 객체가 작음", "데이터 추가와 class-balanced 학습이 필요"],
        ],
        widths=[4.2, 6.0, 5.2],
    )
    callout(
        doc,
        "결론 문장으로 정리",
        "이번 데이터에서는 bbox 라벨이 시맨틱 마스크를 완전히 대체하기 어렵다. 다만 bbox는 빠른 후보 검출에는 사용할 수 있으므로, 정밀 분석용 시맨틱 모델과 보조 검출용 bbox 모델을 목적별로 분리하는 전략이 적절하다.",
    )
    page_break(doc)


def add_discussion(doc: Document) -> None:
    heading(doc, "5. 논의")
    heading(doc, "5.1 라벨링 방식별 장단점", 2)
    paragraph(
        doc,
        "시맨틱 마스크 방식은 라벨링 비용이 높지만, 이번 데이터셋에서는 전반적인 segmentation 성능이 더 높게 나타났다. "
        "특히 Adult worm처럼 형태가 길고 비정형적인 객체에서는 bbox가 실제 객체보다 크게 팽창하여 많은 배경을 포함했고, 이로 인해 IoU와 Dice가 크게 낮아졌다. "
        "반대로 bbox 방식은 객체 위치를 빠르게 표시하기 쉽고, 객체 단위 detection F1에서는 약간 더 좋은 결과를 보였다.",
    )
    add_table(
        doc,
        ["구분", "장점", "단점", "적합한 사용 목적"],
        [
            ["시맨틱 마스크", "정확한 경계와 면적 학습 가능", "라벨링 시간이 길고 작은 객체 경계 품질에 민감", "면적 분석, 정밀 분할, 연구용 정량 분석"],
            ["Bounding box", "라벨링이 빠르고 객체 위치 파악이 쉬움", "배경 포함과 경계 정보 손실이 큼", "1차 후보 검출, 빠른 annotation, 사용자 검수용 화면"],
        ],
        widths=[3.0, 4.2, 4.2, 4.0],
    )
    paragraph(
        doc,
        "따라서 실제 시스템에서는 하나의 방식만 고집하기보다 목적에 따라 조합하는 것이 현실적이다. "
        "예를 들어 사용자가 빠르게 객체 후보를 확인해야 하는 단계에서는 bbox 기반 결과를 보여주고, 최종 데이터 분석에는 시맨틱 마스크 기반 결과를 사용하는 방식이 가능하다.",
    )
    page_break(doc)

    heading(doc, "5.2 데이터 보정 필요성", 2)
    paragraph(
        doc,
        "이번 실험에서 가장 큰 제한은 데이터 수와 클래스 불균형이다. "
        "특히 Larva-L1은 픽셀 수가 너무 적어 일반적인 segmentation loss에서는 충분한 학습 신호를 주기 어렵다. "
        "또한 전체 이미지 resize 과정에서 작은 객체의 크기가 더 줄어들 수 있어, L1과 Egg 같은 소형 객체에는 별도의 보정이 필요하다.",
    )
    bullet(doc, "Class-balanced loss 또는 focal loss를 사용하여 희귀 클래스의 gradient 기여도를 높인다.")
    bullet(doc, "Foreground가 포함된 patch를 더 자주 sampling하여 작은 객체가 학습 batch에서 사라지지 않도록 한다.")
    bullet(doc, "L1과 Egg 주변 crop을 별도로 증강하고, 회전·밝기 변화·blur를 추가하여 배경 변화에 견디게 한다.")
    bullet(doc, "BBox 방식만 사용할 경우에는 box 내부 배경을 모두 전경으로 보지 않도록 weakly supervised refinement를 고려한다.")
    bullet(doc, "최소 100장 이상으로 데이터셋을 확장한 뒤, validation과 test를 라벨별로 stratified하게 구성한다.")
    paragraph(
        doc,
        "이 보정 방향은 단순히 성능을 높이기 위한 기술 목록이 아니라, 이번 결과에서 실제로 확인된 약점을 줄이기 위한 것이다. "
        "L1 클래스의 IoU가 낮게 나온 문제는 모델 구조 변경만으로 해결되기 어렵고, 데이터 분포와 sampling 방법을 함께 바꿔야 한다.",
    )
    page_break(doc)

    heading(doc, "5.3 과적합 해석의 한계", 2)
    paragraph(
        doc,
        "이번 결과에서는 강한 과적합 신호가 보이지 않았지만, validation 데이터가 4장이라는 점은 반드시 고려해야 한다. "
        "작은 validation set에서는 우연히 쉬운 프레임이 포함되면 검증 성능이 좋게 보일 수 있고, 반대로 어려운 프레임이 포함되면 성능이 과도하게 낮게 보일 수 있다. "
        "따라서 현재 결과는 '과적합이 없다'보다는 '현재 분할에서 뚜렷한 과적합 증거는 없다'고 표현하는 것이 정확하다.",
    )
    paragraph(
        doc,
        "또한 원본 데이터가 연속 프레임에 가까울 가능성이 있으므로, train과 test가 완전히 독립적인 촬영 조건인지도 확인할 필요가 있다. "
        "만약 가까운 시간대의 프레임이 서로 매우 비슷하다면 test 성능이 실제 신규 데이터 성능보다 높게 측정될 수 있다. "
        "향후에는 다른 날짜, 다른 조명, 다른 배율에서 촬영한 데이터를 test set에 포함해 모델의 일반화 성능을 확인하는 것이 좋다.",
    )
    callout(
        doc,
        "보고서 결론의 범위",
        "현재 보고서는 제공된 30장 데이터에 대한 정밀 분석이다. "
        "논문 수준의 일반화 결론을 내리려면 데이터 수를 늘리고 반복 실험 또는 교차검증을 추가해야 한다.",
    )
    heading(doc, "5.4 실제 적용 시나리오", 2)
    paragraph(
        doc,
        "BIO AI 창업 프로젝트 관점에서 모델 결과는 연구용 수치만으로 끝나지 않고, 사용자가 실제로 검수하고 활용할 수 있는 흐름으로 연결되어야 한다. "
        "예를 들어 사용자가 원본 이미지를 업로드하면 시스템은 먼저 객체 후보를 빠르게 표시하고, 사용자는 표시된 후보 중 잘못된 부분을 수정한 뒤 최종 mask를 저장할 수 있어야 한다. "
        "이때 bbox 방식은 빠른 후보 표시에는 유리하지만 최종 분석 결과로 바로 사용하기에는 경계가 거칠기 때문에, 시맨틱 마스크 결과와 함께 보여주는 방식이 더 적합하다.",
    )
    add_table(
        doc,
        ["사용 단계", "권장 모델 출력", "사용자 화면", "이유"],
        [
            ["1차 탐색", "bbox 후보 또는 bbox형 mask", "객체 위치를 사각형/반투명 영역으로 표시", "빠르게 객체가 있는 위치를 훑어볼 수 있음"],
            ["정밀 검수", "시맨틱 U-Net mask", "원본 위에 클래스별 색상 overlay 표시", "경계와 면적을 사람이 바로 확인 가능"],
            ["수정 단계", "사용자 보정 mask", "잘못된 blob 삭제, 라벨 변경, 경계 보정", "작은 객체와 희귀 라벨의 오류를 줄일 수 있음"],
            ["분석 저장", "검수 완료 semantic mask", "객체 수, 면적, class별 통계 출력", "연구·보고용 정량 데이터로 활용 가능"],
        ],
        widths=[2.6, 3.7, 5.0, 4.1],
    )
    paragraph(
        doc,
        "이 흐름을 적용하면 bbox와 semantic segmentation을 경쟁 관계로만 볼 필요가 없다. "
        "bbox는 사용자가 빠르게 훑어보는 초기 인터페이스에 쓰고, 최종 통계는 시맨틱 마스크 기반으로 산출하면 두 방식의 장점을 나누어 사용할 수 있다. "
        "특히 현재 데이터처럼 배경이 압도적으로 많고 작은 객체가 흩어져 있는 경우, 사람이 결과를 검수하는 화면까지 고려해야 실제 서비스 품질이 좋아진다.",
    )

    heading(doc, "5.5 후속 실험 설계", 2)
    paragraph(
        doc,
        "후속 실험은 단순히 epoch를 늘리는 방향보다 데이터와 loss, sampling을 바꾸어 원인을 확인하는 방식이 더 적절하다. "
        "현재 결과에서 확인된 약점은 모델이 전체적으로 학습을 못한 것이 아니라, 작은 객체와 희귀 클래스에 대한 학습 신호가 부족하다는 점이기 때문이다. "
        "따라서 다음 실험에서는 한 번에 여러 요소를 바꾸기보다, 하나씩 바꾸고 같은 test set에서 비교해야 한다.",
    )
    add_table(
        doc,
        ["실험 번호", "변경 요소", "기대 효과", "확인할 지표"],
        [
            ["E1", "class weight 적용", "L1과 Egg의 학습 기여도 증가", "class별 IoU, L1 Dice"],
            ["E2", "foreground crop sampling", "작은 객체가 batch에 더 자주 포함됨", "small object recall"],
            ["E3", "Dice loss + CE loss 결합", "전경 mask overlap 개선", "foreground mIoU, mean Dice"],
            ["E4", "bbox 후보 후 semantic refinement", "bbox의 빠른 위치 검출과 mask 정밀도 결합", "detection F1, mask IoU"],
            ["E5", "데이터 100장 이상 확장", "validation/test 신뢰도 향상", "split별 평균과 표준편차"],
        ],
        widths=[2.0, 4.1, 5.0, 4.3],
    )
    paragraph(
        doc,
        "이 계획대로 진행하면 어떤 개선이 실제로 효과가 있었는지 분리해서 판단할 수 있다. "
        "예를 들어 class weight만 바꾼 E1에서 L1 성능이 올라가면 라벨 불균형이 주요 원인이었다고 볼 수 있고, crop sampling을 적용한 E2에서 작은 객체 recall이 올라가면 resize와 sampling 문제가 컸다고 해석할 수 있다. "
        "반대로 데이터 확장 전에는 큰 개선이 없다면 현재 30장 데이터가 모델 성능의 병목이라는 결론을 더 강하게 말할 수 있다.",
    )
    page_break(doc)


def add_conclusion(doc: Document) -> None:
    heading(doc, "6. 결론")
    paragraph(
        doc,
        "본 프로젝트에서는 원본 영상 30장과 대응 마스크 30장을 이용하여 U-Net 기반 segmentation 실험을 수행하였다. "
        "데이터는 학습 21장, 검증 4장, 테스트 5장으로 나누었고, 수작업 시맨틱 마스크와 bbox 변환 라벨을 같은 조건에서 비교하였다. "
        "분석 결과, 정확한 경계와 면적을 요구하는 segmentation 지표에서는 시맨틱 마스크 학습이 bbox 학습보다 확실히 우수했다.",
    )
    paragraph(
        doc,
        "시맨틱 U-Net은 테스트 foreground mIoU 0.526, mean Dice 0.588을 기록했고, bbox U-Net은 foreground mIoU 0.263, mean Dice 0.380을 기록했다. "
        "반면 detection F1에서는 bbox 방식이 0.577로 시맨틱 방식 0.530보다 약간 높았다. "
        "이는 bbox 방식이 객체를 넓게 덮어 위치 검출에는 유리하지만, 실제 경계 분석에는 불리하다는 점을 보여준다.",
    )
    paragraph(
        doc,
        "가장 중요한 발견은 pixel accuracy만으로는 이 데이터셋의 성능을 판단할 수 없다는 점이다. "
        "배경이 99% 이상이기 때문에 전경 클래스의 IoU와 Dice를 따로 확인해야 한다. "
        "또한 Larva-L1처럼 픽셀 비율이 매우 작은 클래스는 현재 방식으로 안정적인 학습이 어려워, 데이터 추가와 class-balanced 학습 전략이 필요하다.",
    )
    heading(doc, "6.1 향후 과제", 2)
    bullet(doc, "데이터셋을 최소 100장 이상으로 확장하고, 촬영 조건별 test set을 따로 구성한다.")
    bullet(doc, "L1과 Egg 같은 작은 객체를 위한 crop-based 학습과 oversampling을 적용한다.")
    bullet(doc, "Weighted Cross Entropy, Dice Loss, Focal Loss를 비교하여 희귀 클래스 성능을 개선한다.")
    bullet(doc, "BBox 라벨은 빠른 검수용으로 활용하고, 최종 분석용 라벨은 시맨틱 마스크 중심으로 유지한다.")
    bullet(doc, "실제 서비스 화면에서는 원본, 예측 mask, bbox 후보, 불확실도 표시를 함께 제공하여 사용자가 빠르게 수정할 수 있도록 한다.")
    page_break(doc)


def add_references_appendix(doc: Document) -> None:
    doc.add_page_break()
    heading(doc, "7. 참고문헌")
    refs = [
        "Corsi, A. K., Wightman, B., & Chalfie, M. (2015). A Transparent Window into Biology: A Primer on Caenorhabditis elegans.",
        "The C. elegans Sequencing Consortium. (1998). Genome sequence of the nematode C. elegans: a platform for investigating biology. Science.",
        "Swierczek, N. A., Giles, A. C., Rankin, C. H., & Kerr, R. A. (2011). High-throughput behavioral analysis in C. elegans. Nature Methods.",
        "Ronneberger, O., Fischer, P., & Brox, T. (2015). U-Net: Convolutional Networks for Biomedical Image Segmentation.",
        "Long, J., Shelhamer, E., & Darrell, T. (2015). Fully Convolutional Networks for Semantic Segmentation.",
        "Lin, T.-Y., Goyal, P., Girshick, R., He, K., & Dollár, P. (2017). Focal Loss for Dense Object Detection.",
        "Milletari, F., Navab, N., & Ahmadi, S.-A. (2016). V-Net: Fully Convolutional Neural Networks for Volumetric Medical Image Segmentation.",
        "BIO AI 창업 프로젝트 실험 데이터 및 U-Net 라벨링 비교 발표 자료, 2026.",
    ]
    for r in refs:
        bullet(doc, r)
    paragraph(
        doc,
        "참고문헌은 본 실험에서 사용한 기본 개념과 평가 해석에 필요한 대표 연구를 중심으로 정리하였다. "
        "세부 구현은 제공 데이터셋과 본 프로젝트에서 생성한 분석 파일을 기준으로 작성하였다.",
    )
    page_break(doc)

    heading(doc, "부록 A. 재현 및 산출물 목록")
    add_table(
        doc,
        ["구분", "파일명 또는 경로", "내용"],
        [
            ["입력 데이터", r"C:\Users\LEEGIWON\Documents\기원문서\maks_frame", "원본 프레임과 마스크 폴더"],
            ["분할 정보", "split_manifest.csv", "학습/검증/테스트 프레임 목록"],
            ["bbox 라벨", "bbox_annotations_left_top_right_bottom.csv", "객체별 left-top/right-bottom 좌표"],
            ["성능 요약", "model_metrics_summary.csv", "split별 pixel accuracy, IoU, Dice, precision, recall"],
            ["클래스 성능", "per_class_test_metrics.csv", "테스트 class별 IoU와 Dice"],
            ["과적합 분석", "overfitting_diagnosis.json", "loss gap과 best epoch 기반 진단"],
            ["그림 자료", "work/analysis/figures/*.png", "보고서 삽입 그래프 및 overlay 이미지"],
        ],
        widths=[2.8, 5.7, 6.9],
    )
    paragraph(
        doc,
        "본 보고서의 모든 수치와 그래프는 같은 split manifest를 기준으로 생성하였다. "
        "따라서 추후 모델 구조나 loss를 바꾸더라도 같은 test set에서 비교하면 실험 간 차이를 더 공정하게 해석할 수 있다.",
    )
    page_break(doc)

    heading(doc, "부록 B. 세부 지표 정의")
    add_table(
        doc,
        ["지표", "정의", "본 보고서에서의 사용 이유"],
        [
            ["Pixel Accuracy", "전체 픽셀 중 정답과 예측이 일치한 비율", "배경 포함 전체 경향 확인용"],
            ["IoU", "예측 영역과 정답 영역의 교집합 / 합집합", "경계와 면적 일치 정도 평가"],
            ["Dice", "2 x 교집합 / (예측 영역 + 정답 영역)", "작은 객체 segmentation 성능 확인"],
            ["Foreground mIoU", "배경을 제외한 전경 클래스 IoU 평균", "배경 편중 영향을 줄인 핵심 지표"],
            ["Detection F1", "객체 단위 precision과 recall의 조화 평균", "후보 위치 검출 관점 비교"],
            ["BBox Tightness", "bbox 안에서 실제 mask가 차지하는 비율", "bbox 라벨의 정보 손실 판단"],
            ["BBox Inflation", "bbox 면적 / 실제 mask 면적", "사각형 라벨의 팽창 정도 확인"],
        ],
        widths=[3.1, 5.5, 6.8],
    )
    paragraph(
        doc,
        "이 지표들을 함께 본 이유는 BIO AI 프로젝트의 목적이 단순히 예측 이미지를 예쁘게 만드는 것이 아니라, "
        "어떤 라벨 방식이 실제 분석에 도움이 되는지 판단하는 것이었기 때문이다. "
        "특히 foreground mIoU와 Dice는 작은 객체 문제를 드러내고, detection F1은 bbox 방식의 실용성을 따로 확인하는 데 유용했다.",
    )
    page_break(doc)

    heading(doc, "부록 C. 제출 전 확인 사항")
    bullet(doc, "표지의 팀원, 학번, 지도교수, 제출일은 실제 제출 양식에 맞게 최종 확인한다.")
    bullet(doc, "데이터 경로와 파일명은 개인 PC 경로를 기준으로 작성되어 있으므로, 학교 제출용에는 필요 시 상대 경로나 설명형 문장으로 바꾼다.")
    bullet(doc, "검증 데이터가 4장이라는 한계는 발표나 질의응답에서 반드시 함께 설명한다.")
    bullet(doc, "성능 수치를 말할 때는 pixel accuracy보다 foreground mIoU와 Dice를 중심으로 설명한다.")
    bullet(doc, "BBox 방식은 segmentation 대체재가 아니라 빠른 후보 검출 또는 라벨링 비용 절감 방식으로 해석한다.")
    paragraph(
        doc,
        "최종적으로 이 보고서는 프로젝트의 성공 결과뿐 아니라 실험에서 드러난 한계를 함께 담고 있다. "
        "캡스톤디자인 보고서에서는 실제 구현 과정에서 무엇을 확인했고, 다음 단계에서 무엇을 고쳐야 하는지가 분명해야 하므로 이러한 한계 정리가 중요하다.",
    )


def main() -> None:
    doc = setup_document()
    add_cover(doc)
    add_summary(doc)
    add_toc(doc)
    add_intro(doc)
    add_background(doc)
    add_methods(doc)
    add_results(doc)
    add_discussion(doc)
    add_conclusion(doc)
    add_references_appendix(doc)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(OUT))
    print(OUT)


if __name__ == "__main__":
    main()
