from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


ROOT = Path(__file__).resolve().parents[2]
PYDEPS = ROOT / "work" / "pydeps"
if PYDEPS.exists():
    sys.path.insert(0, str(PYDEPS))

import numpy as np
from PIL import Image, ImageDraw, ImageFont

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F


DATA_DIR = ROOT / "work" / "data"
ANALYSIS_DIR = ROOT / "work" / "analysis"
FIG_DIR = ANALYSIS_DIR / "figures"
MODEL_DIR = ANALYSIS_DIR / "models"

CLASS_COLORS = {
    0: (0, 0, 0),
    1: (255, 0, 0),
    2: (0, 255, 0),
    3: (0, 0, 255),
}
CLASS_NAMES = {
    0: "Background",
    1: "Adult worm / Red",
    2: "Egg-small object / Green",
    3: "Larva-L1 / Blue",
}
FG_CLASSES = [1, 2, 3]


@dataclass
class Pair:
    index: int
    stem: str
    frame: Path
    mask: Path
    split: str


def ensure_dirs() -> None:
    ANALYSIS_DIR.mkdir(parents=True, exist_ok=True)
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DIR.mkdir(parents=True, exist_ok=True)


def pair_files() -> List[Pair]:
    frames = sorted((DATA_DIR / "frame").glob("*.png"))
    masks_by_name = {p.name.replace("m.png", ".png"): p for p in (DATA_DIR / "mask").glob("*.png")}
    pairs: List[Pair] = []
    for i, frame in enumerate(frames):
        mask = masks_by_name.get(frame.name)
        if mask is None:
            raise FileNotFoundError(f"Missing mask for {frame.name}")
        if i < 21:
            split = "train"
        elif i < 25:
            split = "validation"
        else:
            split = "test"
        pairs.append(Pair(index=i, stem=frame.stem, frame=frame, mask=mask, split=split))
    if len(pairs) != 30:
        raise ValueError(f"Expected 30 pairs, found {len(pairs)}")
    return pairs


def load_image(path: Path, size: int | None = None, nearest: bool = False) -> np.ndarray:
    im = Image.open(path).convert("RGB")
    if size is not None:
        resample = Image.Resampling.NEAREST if nearest else Image.Resampling.BILINEAR
        im = im.resize((size, size), resample)
    return np.asarray(im)


def rgb_to_mask(arr: np.ndarray) -> np.ndarray:
    r = arr[..., 0]
    g = arr[..., 1]
    b = arr[..., 2]
    mask = np.zeros(arr.shape[:2], dtype=np.uint8)
    mask[(r > 127) & (g < 128) & (b < 128)] = 1
    mask[(g > 127) & (r < 128) & (b < 128)] = 2
    mask[(b > 127) & (r < 128) & (g < 128)] = 3
    return mask


def mask_to_rgb(mask: np.ndarray) -> np.ndarray:
    out = np.zeros((*mask.shape, 3), dtype=np.uint8)
    for cls, color in CLASS_COLORS.items():
        out[mask == cls] = color
    return out


def overlay_image(image: np.ndarray, mask: np.ndarray, alpha: float = 0.55) -> np.ndarray:
    base = image.astype(np.float32).copy()
    color = mask_to_rgb(mask).astype(np.float32)
    fg = mask > 0
    base[fg] = base[fg] * (1.0 - alpha) + color[fg] * alpha
    return np.clip(base, 0, 255).astype(np.uint8)


def connected_components(mask: np.ndarray, cls: int, min_area: int = 2) -> List[Dict[str, float]]:
    binary = mask == cls
    ys, xs = np.nonzero(binary)
    visited = np.zeros(mask.shape, dtype=np.bool_)
    comps: List[Dict[str, float]] = []
    h, w = mask.shape
    for sy, sx in zip(ys.tolist(), xs.tolist()):
        if visited[sy, sx]:
            continue
        stack = [(sy, sx)]
        visited[sy, sx] = True
        pix: List[Tuple[int, int]] = []
        while stack:
            y, x = stack.pop()
            pix.append((y, x))
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dy == 0 and dx == 0:
                        continue
                    ny = y + dy
                    nx = x + dx
                    if 0 <= ny < h and 0 <= nx < w and not visited[ny, nx] and binary[ny, nx]:
                        visited[ny, nx] = True
                        stack.append((ny, nx))
        area = len(pix)
        if area < min_area:
            continue
        py = [p[0] for p in pix]
        px = [p[1] for p in pix]
        y0, y1 = min(py), max(py)
        x0, x1 = min(px), max(px)
        box_area = (x1 - x0 + 1) * (y1 - y0 + 1)
        comps.append(
            {
                "class_id": cls,
                "class_name": CLASS_NAMES[cls],
                "x_min": int(x0),
                "y_min": int(y0),
                "x_max": int(x1),
                "y_max": int(y1),
                "width": int(x1 - x0 + 1),
                "height": int(y1 - y0 + 1),
                "mask_area": int(area),
                "bbox_area": int(box_area),
                "tightness": float(area / max(box_area, 1)),
            }
        )
    return comps


def make_bbox_mask(mask: np.ndarray, min_area: int = 2) -> Tuple[np.ndarray, List[Dict[str, float]]]:
    comps: List[Dict[str, float]] = []
    for cls in FG_CLASSES:
        comps.extend(connected_components(mask, cls, min_area=min_area))
    out = np.zeros_like(mask)
    # Large boxes first, small boxes last: small rare-object boxes remain visible
    # if coarse rectangles overlap.
    for comp in sorted(comps, key=lambda c: c["bbox_area"], reverse=True):
        cls = int(comp["class_id"])
        out[int(comp["y_min"]) : int(comp["y_max"]) + 1, int(comp["x_min"]) : int(comp["x_max"]) + 1] = cls
    return out, comps


def write_csv(path: Path, rows: Sequence[Dict[str, object]], fieldnames: Sequence[str] | None = None) -> None:
    if fieldnames is None:
        keys = []
        for row in rows:
            for key in row:
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def analyze_dataset(pairs: List[Pair], eval_size: int) -> Dict[str, object]:
    split_rows = []
    stats_rows = []
    bbox_rows = []
    class_pixel_counter = Counter()
    split_pixel_counter: Dict[str, Counter] = defaultdict(Counter)
    class_object_counter = Counter()
    per_frame_rows = []
    bbox_tightness: Dict[int, List[float]] = defaultdict(list)
    bbox_inflation: Dict[int, List[float]] = defaultdict(list)
    bbox_label_confusion = np.zeros((4, 4), dtype=np.int64)

    for pair in pairs:
        mask = rgb_to_mask(load_image(pair.mask))
        h, w = mask.shape
        counts = Counter(mask.reshape(-1).tolist())
        split_rows.append({"index": pair.index, "image": pair.frame.name, "mask": pair.mask.name, "split": pair.split})
        for cls in range(4):
            class_pixel_counter[cls] += counts.get(cls, 0)
            split_pixel_counter[pair.split][cls] += counts.get(cls, 0)
            stats_rows.append(
                {
                    "image": pair.frame.name,
                    "split": pair.split,
                    "class_id": cls,
                    "class_name": CLASS_NAMES[cls],
                    "pixels": counts.get(cls, 0),
                    "pixel_ratio": counts.get(cls, 0) / (h * w),
                }
            )
        bbox_mask, comps = make_bbox_mask(mask)
        for gt, bx in zip(mask.reshape(-1), bbox_mask.reshape(-1)):
            bbox_label_confusion[int(gt), int(bx)] += 1
        for instance_id, comp in enumerate(comps, start=1):
            cls = int(comp["class_id"])
            class_object_counter[cls] += 1
            bbox_tightness[cls].append(float(comp["tightness"]))
            bbox_inflation[cls].append(float(comp["bbox_area"]) / max(float(comp["mask_area"]), 1.0))
            row = {
                "image": pair.frame.name,
                "split": pair.split,
                "instance_id": instance_id,
                **comp,
                "left_top": f"({int(comp['x_min'])}, {int(comp['y_min'])})",
                "right_bottom": f"({int(comp['x_max'])}, {int(comp['y_max'])})",
            }
            bbox_rows.append(row)
        per_frame_rows.append(
            {
                "index": pair.index,
                "image": pair.frame.name,
                "split": pair.split,
                "background_ratio": counts.get(0, 0) / (h * w),
                "adult_ratio": counts.get(1, 0) / (h * w),
                "egg_ratio": counts.get(2, 0) / (h * w),
                "l1_ratio": counts.get(3, 0) / (h * w),
                "foreground_ratio": (counts.get(1, 0) + counts.get(2, 0) + counts.get(3, 0)) / (h * w),
            }
        )

    write_csv(ANALYSIS_DIR / "split_manifest.csv", split_rows)
    write_csv(ANALYSIS_DIR / "mask_pixel_stats.csv", stats_rows)
    write_csv(ANALYSIS_DIR / "bbox_annotations_left_top_right_bottom.csv", bbox_rows)
    write_csv(ANALYSIS_DIR / "per_frame_area_ratios.csv", per_frame_rows)

    total_pixels = sum(class_pixel_counter.values())
    split_counts = Counter(p.split for p in pairs)
    dataset_summary = {
        "total_pairs": len(pairs),
        "image_size": [1024, 1024],
        "eval_train_size": eval_size,
        "split_counts": dict(split_counts),
        "split_policy": "Chronological file-order split: train frame_00000-00020, validation frame_00021-00024, test frame_00025-00029.",
        "class_pixel_counts": {CLASS_NAMES[k]: int(v) for k, v in class_pixel_counter.items()},
        "class_pixel_ratios": {CLASS_NAMES[k]: float(v / total_pixels) for k, v in class_pixel_counter.items()},
        "class_object_counts": {CLASS_NAMES[k]: int(class_object_counter[k]) for k in FG_CLASSES},
        "bbox_count": len(bbox_rows),
        "bbox_tightness_mean": {
            CLASS_NAMES[k]: float(np.mean(v)) if v else None for k, v in bbox_tightness.items()
        },
        "bbox_inflation_mean": {
            CLASS_NAMES[k]: float(np.mean(v)) if v else None for k, v in bbox_inflation.items()
        },
        "bbox_label_confusion": bbox_label_confusion.tolist(),
    }
    (ANALYSIS_DIR / "dataset_summary.json").write_text(json.dumps(dataset_summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return dataset_summary


def plot_dataset_figures(pairs: List[Pair], summary: Dict[str, object]) -> None:
    plt.style.use("seaborn-v0_8-whitegrid")
    colors = ["#0f172a", "#dc2626", "#16a34a", "#2563eb"]

    ratios = summary["class_pixel_ratios"]
    labels = ["Background", "Adult", "Egg", "L1"]
    values = [ratios.get(CLASS_NAMES[i], 0.0) * 100 for i in range(4)]
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=160)
    bars = ax.bar(labels, values, color=colors)
    ax.set_ylabel("Pixel ratio (%)")
    ax.set_title("Class pixel distribution across 30 masks")
    ax.set_yscale("log")
    ax.set_ylim(0.001, max(values) * 1.7)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, val * 1.05, f"{val:.3f}%", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "class_pixel_distribution.png", transparent=False)
    plt.close(fig)

    obj_counts = summary["class_object_counts"]
    obj_values = [obj_counts.get(CLASS_NAMES[i], 0) for i in FG_CLASSES]
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=160)
    bars = ax.bar(["Adult", "Egg", "L1"], obj_values, color=colors[1:])
    ax.set_ylabel("Connected components")
    ax.set_title("Object counts generated from semantic masks")
    for bar, val in zip(bars, obj_values):
        ax.text(bar.get_x() + bar.get_width() / 2, val + max(obj_values) * 0.02, str(val), ha="center", fontsize=10)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "object_counts_by_class.png", transparent=False)
    plt.close(fig)

    per_frame = []
    with (ANALYSIS_DIR / "per_frame_area_ratios.csv").open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            per_frame.append(row)
    x = [int(r["index"]) for r in per_frame]
    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=160)
    ax.plot(x, [float(r["foreground_ratio"]) * 100 for r in per_frame], "-o", label="Foreground total", color="#111827")
    ax.plot(x, [float(r["adult_ratio"]) * 100 for r in per_frame], "-o", label="Adult", color="#dc2626", alpha=0.85)
    ax.plot(x, [float(r["egg_ratio"]) * 100 for r in per_frame], "-o", label="Egg", color="#16a34a", alpha=0.85)
    ax.plot(x, [float(r["l1_ratio"]) * 100 for r in per_frame], "-o", label="L1", color="#2563eb", alpha=0.85)
    ax.axvspan(-0.5, 20.5, color="#e0f2fe", alpha=0.35, label="Train")
    ax.axvspan(20.5, 24.5, color="#fef3c7", alpha=0.35, label="Validation")
    ax.axvspan(24.5, 29.5, color="#fee2e2", alpha=0.35, label="Test")
    ax.set_xlabel("Frame index")
    ax.set_ylabel("Area ratio (%)")
    ax.set_title("Foreground area is very small relative to background")
    ax.legend(ncol=4, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "per_frame_area_ratio.png", transparent=False)
    plt.close(fig)

    bbox_rows = []
    with (ANALYSIS_DIR / "bbox_annotations_left_top_right_bottom.csv").open(encoding="utf-8") as f:
        for row in csv.DictReader(f):
            bbox_rows.append(row)
    tight_data = []
    inflation_data = []
    for cls in FG_CLASSES:
        rows = [r for r in bbox_rows if int(r["class_id"]) == cls]
        tight_data.append([float(r["tightness"]) for r in rows])
        inflation_data.append([float(r["bbox_area"]) / max(float(r["mask_area"]), 1.0) for r in rows])
    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=160)
    bp = ax.boxplot(tight_data, tick_labels=["Adult", "Egg", "L1"], patch_artist=True, showfliers=False)
    for patch, c in zip(bp["boxes"], colors[1:]):
        patch.set_facecolor(c)
        patch.set_alpha(0.55)
    ax.set_ylabel("Mask area / bbox area")
    ax.set_title("Bounding-box tightness: lower means more background inside labels")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "bbox_tightness_by_class.png", transparent=False)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4.5), dpi=160)
    means = [np.mean(v) if v else 0 for v in inflation_data]
    bars = ax.bar(["Adult", "Egg", "L1"], means, color=colors[1:])
    ax.set_ylabel("BBox area / mask area")
    ax.set_title("Box-label inflation caused by rectangle conversion")
    for bar, val in zip(bars, means):
        ax.text(bar.get_x() + bar.get_width() / 2, val * 1.02, f"{val:.1f}x", ha="center", fontsize=10)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "bbox_inflation.png", transparent=False)
    plt.close(fig)

    split_counts = summary["split_counts"]
    fig, ax = plt.subplots(figsize=(7, 4.2), dpi=160)
    bars = ax.bar(["Train", "Validation", "Test"], [split_counts["train"], split_counts["validation"], split_counts["test"]], color=["#0f766e", "#d97706", "#b91c1c"])
    ax.set_ylabel("Image-mask pairs")
    ax.set_title("Dataset split: 30 total paired samples")
    ax.set_ylim(0, 24)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5, str(int(bar.get_height())), ha="center")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "split_distribution.png", transparent=False)
    plt.close(fig)


class ConvBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class TinyUNet(nn.Module):
    def __init__(self, num_classes: int = 4, base: int = 8):
        super().__init__()
        self.d1 = ConvBlock(3, base)
        self.d2 = ConvBlock(base, base * 2)
        self.d3 = ConvBlock(base * 2, base * 4)
        self.mid = ConvBlock(base * 4, base * 8)
        self.u3 = nn.ConvTranspose2d(base * 8, base * 4, 2, stride=2)
        self.c3 = ConvBlock(base * 8, base * 4)
        self.u2 = nn.ConvTranspose2d(base * 4, base * 2, 2, stride=2)
        self.c2 = ConvBlock(base * 4, base * 2)
        self.u1 = nn.ConvTranspose2d(base * 2, base, 2, stride=2)
        self.c1 = ConvBlock(base * 2, base)
        self.out = nn.Conv2d(base, num_classes, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        d1 = self.d1(x)
        d2 = self.d2(F.max_pool2d(d1, 2))
        d3 = self.d3(F.max_pool2d(d2, 2))
        mid = self.mid(F.max_pool2d(d3, 2))
        x = self.u3(mid)
        x = self.c3(torch.cat([x, d3], dim=1))
        x = self.u2(x)
        x = self.c2(torch.cat([x, d2], dim=1))
        x = self.u1(x)
        x = self.c1(torch.cat([x, d1], dim=1))
        return self.out(x)


def dice_loss(logits: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    probs = torch.softmax(logits, dim=1)
    one_hot = F.one_hot(target, num_classes=logits.shape[1]).permute(0, 3, 1, 2).float()
    probs = probs[:, 1:]
    one_hot = one_hot[:, 1:]
    inter = (probs * one_hot).sum(dim=(0, 2, 3))
    denom = probs.sum(dim=(0, 2, 3)) + one_hot.sum(dim=(0, 2, 3))
    dice = (2 * inter + eps) / (denom + eps)
    return 1.0 - dice.mean()


def compute_class_weights(masks: Sequence[np.ndarray]) -> torch.Tensor:
    counts = np.zeros(4, dtype=np.float64)
    for mask in masks:
        counts += np.bincount(mask.reshape(-1), minlength=4)
    freq = counts / max(counts.sum(), 1)
    weights = 1.0 / np.sqrt(freq + 1e-8)
    weights = weights / weights[1:].mean()
    weights = np.clip(weights, 0.2, 8.0)
    weights[0] = min(weights[0], 0.25)
    return torch.tensor(weights, dtype=torch.float32)


def prepare_arrays(pairs: List[Pair], size: int) -> Dict[str, Dict[str, List[np.ndarray]]]:
    data = {
        "image": defaultdict(list),
        "true_mask": defaultdict(list),
        "bbox_mask": defaultdict(list),
        "name": defaultdict(list),
    }
    for pair in pairs:
        img = load_image(pair.frame, size=size, nearest=False).astype(np.float32) / 255.0
        true_mask = rgb_to_mask(load_image(pair.mask, size=size, nearest=True))
        bbox_mask, _ = make_bbox_mask(true_mask, min_area=1)
        data["image"][pair.split].append(img)
        data["true_mask"][pair.split].append(true_mask)
        data["bbox_mask"][pair.split].append(bbox_mask)
        data["name"][pair.split].append(pair.frame.name)
    return data


def augment_patch(img: np.ndarray, mask: np.ndarray, rng: random.Random) -> Tuple[np.ndarray, np.ndarray]:
    if rng.random() < 0.5:
        img = np.flip(img, axis=1).copy()
        mask = np.flip(mask, axis=1).copy()
    if rng.random() < 0.5:
        img = np.flip(img, axis=0).copy()
        mask = np.flip(mask, axis=0).copy()
    k = rng.randint(0, 3)
    if k:
        img = np.rot90(img, k, axes=(0, 1)).copy()
        mask = np.rot90(mask, k, axes=(0, 1)).copy()
    return img, mask


def sample_batch(
    images: Sequence[np.ndarray],
    masks: Sequence[np.ndarray],
    fg_coords: Sequence[np.ndarray],
    batch_size: int,
    patch_size: int,
    rng: random.Random,
) -> Tuple[torch.Tensor, torch.Tensor]:
    xs = []
    ys = []
    h, w = masks[0].shape
    half = patch_size // 2
    for _ in range(batch_size):
        idx = rng.randrange(len(images))
        coords = fg_coords[idx]
        if len(coords) > 0 and rng.random() < 0.82:
            cy, cx = coords[rng.randrange(len(coords))]
            cy += rng.randint(-patch_size // 4, patch_size // 4)
            cx += rng.randint(-patch_size // 4, patch_size // 4)
        else:
            cy = rng.randrange(h)
            cx = rng.randrange(w)
        y0 = int(np.clip(cy - half, 0, h - patch_size))
        x0 = int(np.clip(cx - half, 0, w - patch_size))
        img_patch = images[idx][y0 : y0 + patch_size, x0 : x0 + patch_size]
        mask_patch = masks[idx][y0 : y0 + patch_size, x0 : x0 + patch_size]
        img_patch, mask_patch = augment_patch(img_patch, mask_patch, rng)
        xs.append(np.transpose(img_patch, (2, 0, 1)))
        ys.append(mask_patch)
    x = torch.tensor(np.stack(xs), dtype=torch.float32)
    y = torch.tensor(np.stack(ys), dtype=torch.long)
    return x, y


def confusion_matrix(pred: np.ndarray, target: np.ndarray, classes: int = 4) -> np.ndarray:
    idx = target.reshape(-1) * classes + pred.reshape(-1)
    return np.bincount(idx, minlength=classes * classes).reshape(classes, classes)


def metrics_from_conf(conf: np.ndarray) -> Dict[str, float]:
    total = conf.sum()
    out: Dict[str, float] = {"pixel_accuracy": float(np.trace(conf) / max(total, 1))}
    ious = []
    dices = []
    recalls = []
    precisions = []
    for cls in range(4):
        tp = conf[cls, cls]
        fp = conf[:, cls].sum() - tp
        fn = conf[cls, :].sum() - tp
        iou = tp / max(tp + fp + fn, 1)
        dice = 2 * tp / max(2 * tp + fp + fn, 1)
        recall = tp / max(tp + fn, 1)
        precision = tp / max(tp + fp, 1)
        out[f"iou_class_{cls}"] = float(iou)
        out[f"dice_class_{cls}"] = float(dice)
        out[f"recall_class_{cls}"] = float(recall)
        out[f"precision_class_{cls}"] = float(precision)
        if cls > 0:
            ious.append(iou)
            dices.append(dice)
            recalls.append(recall)
            precisions.append(precision)
    out["foreground_mIoU"] = float(np.mean(ious))
    out["foreground_mean_dice"] = float(np.mean(dices))
    out["foreground_mean_recall"] = float(np.mean(recalls))
    out["foreground_mean_precision"] = float(np.mean(precisions))
    return out


@torch.no_grad()
def evaluate_model(
    model: nn.Module,
    images: Sequence[np.ndarray],
    eval_target_masks: Sequence[np.ndarray],
    loss_target_masks: Sequence[np.ndarray],
    criterion,
    device: torch.device,
) -> Tuple[float, np.ndarray, Dict[str, float], List[np.ndarray]]:
    model.eval()
    total_loss = 0.0
    conf = np.zeros((4, 4), dtype=np.int64)
    preds: List[np.ndarray] = []
    for img, eval_mask, loss_mask in zip(images, eval_target_masks, loss_target_masks):
        x = torch.tensor(np.transpose(img, (2, 0, 1))[None], dtype=torch.float32, device=device)
        y_loss = torch.tensor(loss_mask[None], dtype=torch.long, device=device)
        logits = model(x)
        loss = criterion(logits, y_loss)
        total_loss += float(loss.item())
        pred = torch.argmax(logits, dim=1).cpu().numpy()[0].astype(np.uint8)
        preds.append(pred)
        conf += confusion_matrix(pred, eval_mask)
    metrics = metrics_from_conf(conf)
    return total_loss / max(len(images), 1), conf, metrics, preds


def train_one(
    label_mode: str,
    data: Dict[str, Dict[str, List[np.ndarray]]],
    epochs: int,
    steps: int,
    batch_size: int,
    patch_size: int,
    seed: int,
) -> Tuple[Dict[str, object], List[Dict[str, object]], Dict[str, List[np.ndarray]]]:
    target_key = "true_mask" if label_mode == "semantic_mask" else "bbox_mask"
    device = torch.device("cpu")
    torch.manual_seed(seed)
    rng = random.Random(seed)
    model = TinyUNet(num_classes=4, base=8).to(device)
    weights = compute_class_weights(data[target_key]["train"]).to(device)

    def criterion(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return F.cross_entropy(logits, target, weight=weights) + 0.45 * dice_loss(logits, target)

    optimizer = torch.optim.AdamW(model.parameters(), lr=2.5e-3, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(epochs, 1), eta_min=3e-4)
    fg_coords = [np.argwhere(mask > 0) for mask in data[target_key]["train"]]
    history: List[Dict[str, object]] = []
    best_state = None
    best_val_loss = float("inf")
    best_epoch = -1

    for epoch in range(1, epochs + 1):
        model.train()
        losses = []
        for _ in range(steps):
            x, y = sample_batch(
                data["image"]["train"],
                data[target_key]["train"],
                fg_coords,
                batch_size=batch_size,
                patch_size=patch_size,
                rng=rng,
            )
            x = x.to(device)
            y = y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = criterion(logits, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.item()))
        scheduler.step()
        val_loss, _, val_metrics, _ = evaluate_model(
            model,
            data["image"]["validation"],
            data["true_mask"]["validation"],
            data[target_key]["validation"],
            criterion,
            device,
        )
        train_loss = float(np.mean(losses))
        row = {
            "model": label_mode,
            "epoch": epoch,
            "train_loss": train_loss,
            "validation_loss_on_training_label": val_loss,
            "validation_foreground_mIoU_vs_semantic": val_metrics["foreground_mIoU"],
            "validation_foreground_dice_vs_semantic": val_metrics["foreground_mean_dice"],
            "learning_rate": scheduler.get_last_lr()[0],
        }
        history.append(row)
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        if epoch == 1 or epoch % 5 == 0 or epoch == epochs:
            print(
                f"{label_mode} epoch {epoch:03d}/{epochs} train_loss={train_loss:.4f} "
                f"val_loss={val_loss:.4f} val_mIoU={val_metrics['foreground_mIoU']:.4f}",
                flush=True,
            )

    if best_state is not None:
        model.load_state_dict(best_state)
    torch.save(model.state_dict(), MODEL_DIR / f"{label_mode}_tiny_unet.pt")

    split_results = {}
    for split in ("train", "validation", "test"):
        eval_loss, conf, metrics, preds = evaluate_model(
            model,
            data["image"][split],
            data["true_mask"][split],
            data[target_key][split],
            criterion,
            device,
        )
        split_results[split] = {
            "loss_on_training_label": eval_loss,
            "confusion": conf.tolist(),
            "metrics_vs_semantic": metrics,
            "predictions": preds,
        }

    final = {
        "model": label_mode,
        "best_epoch": best_epoch,
        "best_validation_loss_on_training_label": best_val_loss,
        "class_weights": [float(x) for x in weights.cpu().numpy().tolist()],
        "splits": {
            split: {
                "loss_on_training_label": split_results[split]["loss_on_training_label"],
                "metrics_vs_semantic": split_results[split]["metrics_vs_semantic"],
                "confusion": split_results[split]["confusion"],
            }
            for split in ("train", "validation", "test")
        },
    }
    return final, history, {split: split_results[split]["predictions"] for split in ("train", "validation", "test")}


def components_to_boxes(mask: np.ndarray, min_area: int = 3) -> List[Dict[str, float]]:
    boxes: List[Dict[str, float]] = []
    for cls in FG_CLASSES:
        boxes.extend(connected_components(mask, cls, min_area=min_area))
    return boxes


def box_iou(a: Dict[str, float], b: Dict[str, float]) -> float:
    x0 = max(float(a["x_min"]), float(b["x_min"]))
    y0 = max(float(a["y_min"]), float(b["y_min"]))
    x1 = min(float(a["x_max"]), float(b["x_max"]))
    y1 = min(float(a["y_max"]), float(b["y_max"]))
    inter = max(0.0, x1 - x0 + 1) * max(0.0, y1 - y0 + 1)
    area_a = (float(a["x_max"]) - float(a["x_min"]) + 1) * (float(a["y_max"]) - float(a["y_min"]) + 1)
    area_b = (float(b["x_max"]) - float(b["x_min"]) + 1) * (float(b["y_max"]) - float(b["y_min"]) + 1)
    return inter / max(area_a + area_b - inter, 1e-9)


def detection_metrics(
    true_masks: Sequence[np.ndarray],
    pred_masks: Sequence[np.ndarray],
    iou_threshold: float = 0.5,
) -> Dict[str, float]:
    totals = {cls: {"tp": 0, "fp": 0, "fn": 0} for cls in FG_CLASSES}
    for true, pred in zip(true_masks, pred_masks):
        true_boxes = components_to_boxes(true, min_area=2)
        pred_boxes = components_to_boxes(pred, min_area=5)
        for cls in FG_CLASSES:
            gt = [b for b in true_boxes if int(b["class_id"]) == cls]
            pr = [b for b in pred_boxes if int(b["class_id"]) == cls]
            used = set()
            for pi, pb in enumerate(pr):
                best = -1
                best_iou = 0.0
                for gi, gb in enumerate(gt):
                    if gi in used:
                        continue
                    iou = box_iou(pb, gb)
                    if iou > best_iou:
                        best_iou = iou
                        best = gi
                if best >= 0 and best_iou >= iou_threshold:
                    totals[cls]["tp"] += 1
                    used.add(best)
                else:
                    totals[cls]["fp"] += 1
            totals[cls]["fn"] += max(0, len(gt) - len(used))
    out: Dict[str, float] = {}
    ps, rs, fs = [], [], []
    for cls in FG_CLASSES:
        tp = totals[cls]["tp"]
        fp = totals[cls]["fp"]
        fn = totals[cls]["fn"]
        p = tp / max(tp + fp, 1)
        r = tp / max(tp + fn, 1)
        f1 = 2 * p * r / max(p + r, 1e-9)
        out[f"{CLASS_NAMES[cls]}_precision"] = p
        out[f"{CLASS_NAMES[cls]}_recall"] = r
        out[f"{CLASS_NAMES[cls]}_f1"] = f1
        out[f"{CLASS_NAMES[cls]}_tp"] = tp
        out[f"{CLASS_NAMES[cls]}_fp"] = fp
        out[f"{CLASS_NAMES[cls]}_fn"] = fn
        ps.append(p)
        rs.append(r)
        fs.append(f1)
    out["mean_precision"] = float(np.mean(ps))
    out["mean_recall"] = float(np.mean(rs))
    out["mean_f1"] = float(np.mean(fs))
    return out


def evaluate_bbox_label_upper_bound(data: Dict[str, Dict[str, List[np.ndarray]]]) -> Dict[str, object]:
    rows = []
    conf_total = np.zeros((4, 4), dtype=np.int64)
    for split in ("train", "validation", "test"):
        conf = np.zeros((4, 4), dtype=np.int64)
        for true, box in zip(data["true_mask"][split], data["bbox_mask"][split]):
            conf += confusion_matrix(box, true)
        conf_total += conf
        metrics = metrics_from_conf(conf)
        rows.append({"model": "bbox_label_upper_bound", "split": split, **metrics})
    return {"rows": rows, "confusion_all": conf_total.tolist(), "metrics_all": metrics_from_conf(conf_total)}


def plot_training_and_metrics(
    history: List[Dict[str, object]],
    final_results: Sequence[Dict[str, object]],
    bbox_upper: Dict[str, object],
) -> None:
    def hist_for(model: str) -> List[Dict[str, object]]:
        return [r for r in history if r["model"] == model]

    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=160)
    for model, color in [("semantic_mask", "#0891b2"), ("bbox_mask", "#f97316")]:
        rows = hist_for(model)
        x = [int(r["epoch"]) for r in rows]
        ax.plot(x, [float(r["train_loss"]) for r in rows], color=color, linestyle="-", label=f"{model} train")
        ax.plot(x, [float(r["validation_loss_on_training_label"]) for r in rows], color=color, linestyle="--", label=f"{model} validation")
    ax.set_title("Training vs validation loss")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Loss")
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "training_loss_curves.png", transparent=False)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=160)
    for model, color in [("semantic_mask", "#0891b2"), ("bbox_mask", "#f97316")]:
        rows = hist_for(model)
        x = [int(r["epoch"]) for r in rows]
        ax.plot(x, [float(r["validation_foreground_dice_vs_semantic"]) for r in rows], color=color, label=f"{model}")
    ax.set_title("Validation foreground Dice vs semantic masks")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Mean Dice (foreground)")
    ax.set_ylim(0, 1.0)
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "validation_dice_curves.png", transparent=False)
    plt.close(fig)

    result_by_model = {r["model"]: r for r in final_results}
    metric_names = [
        ("pixel_accuracy", "Pixel Acc."),
        ("foreground_mIoU", "FG mIoU"),
        ("foreground_mean_dice", "FG Dice"),
        ("foreground_mean_recall", "FG Recall"),
        ("foreground_mean_precision", "FG Precision"),
    ]
    models = ["semantic_mask", "bbox_mask", "bbox_label_upper_bound"]
    display = ["Semantic U-Net", "BBox-supervised U-Net", "BBox labels only"]
    vals = []
    for model in models:
        if model == "bbox_label_upper_bound":
            metrics = next(r for r in bbox_upper["rows"] if r["split"] == "test")
        else:
            metrics = result_by_model[model]["splits"]["test"]["metrics_vs_semantic"]
        vals.append([float(metrics[m[0]]) for m in metric_names])
    x = np.arange(len(metric_names))
    width = 0.25
    fig, ax = plt.subplots(figsize=(10, 5), dpi=160)
    for i, (row, name, color) in enumerate(zip(vals, display, ["#0891b2", "#f97316", "#64748b"])):
        ax.bar(x + (i - 1) * width, row, width, label=name, color=color)
    ax.set_xticks(x)
    ax.set_xticklabels([m[1] for m in metric_names])
    ax.set_ylim(0, 1.02)
    ax.set_ylabel("Score")
    ax.set_title("Test-set performance by labeling strategy")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "test_metric_comparison.png", transparent=False)
    plt.close(fig)

    per_class_metrics = []
    for cls in FG_CLASSES:
        row = {"class": CLASS_NAMES[cls].split(" / ")[0]}
        for model in ("semantic_mask", "bbox_mask"):
            metrics = result_by_model[model]["splits"]["test"]["metrics_vs_semantic"]
            row[f"{model}_iou"] = float(metrics[f"iou_class_{cls}"])
            row[f"{model}_dice"] = float(metrics[f"dice_class_{cls}"])
        per_class_metrics.append(row)
    x = np.arange(len(FG_CLASSES))
    fig, ax = plt.subplots(figsize=(9, 4.8), dpi=160)
    ax.bar(x - 0.18, [r["semantic_mask_iou"] for r in per_class_metrics], 0.36, color="#0891b2", label="Semantic U-Net")
    ax.bar(x + 0.18, [r["bbox_mask_iou"] for r in per_class_metrics], 0.36, color="#f97316", label="BBox-supervised U-Net")
    ax.set_xticks(x)
    ax.set_xticklabels([r["class"] for r in per_class_metrics])
    ax.set_ylim(0, 1.0)
    ax.set_ylabel("IoU")
    ax.set_title("Per-class test IoU")
    ax.legend(fontsize=9)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "per_class_iou.png", transparent=False)
    plt.close(fig)

    write_csv(ANALYSIS_DIR / "per_class_test_metrics.csv", per_class_metrics)

    for result in final_results:
        conf = np.asarray(result["splits"]["test"]["confusion"], dtype=np.float64)
        conf_norm = conf / np.maximum(conf.sum(axis=1, keepdims=True), 1)
        fig, ax = plt.subplots(figsize=(5.5, 4.8), dpi=160)
        im = ax.imshow(conf_norm, cmap="Blues", vmin=0, vmax=1)
        ax.set_xticks(range(4))
        ax.set_yticks(range(4))
        ax.set_xticklabels(["BG", "Adult", "Egg", "L1"])
        ax.set_yticklabels(["BG", "Adult", "Egg", "L1"])
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.set_title(f"Test confusion matrix: {result['model']}")
        for i in range(4):
            for j in range(4):
                ax.text(j, i, f"{conf_norm[i, j]:.2f}", ha="center", va="center", fontsize=8)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        fig.tight_layout()
        fig.savefig(FIG_DIR / f"confusion_{result['model']}.png", transparent=False)
        plt.close(fig)


def create_qualitative_images(
    data: Dict[str, Dict[str, List[np.ndarray]]],
    predictions: Dict[str, Dict[str, List[np.ndarray]]],
) -> None:
    img = (data["image"]["test"][0] * 255).astype(np.uint8)
    true = data["true_mask"]["test"][0]
    bbox = data["bbox_mask"]["test"][0]
    sem_pred = predictions["semantic_mask"]["test"][0]
    box_pred = predictions["bbox_mask"]["test"][0]
    panels = [
        ("Original", img),
        ("True semantic mask", overlay_image(img, true)),
        ("BBox label raster", overlay_image(img, bbox)),
        ("Semantic U-Net pred.", overlay_image(img, sem_pred)),
        ("BBox-supervised pred.", overlay_image(img, box_pred)),
    ]
    panel_w, panel_h = 360, 360
    canvas = Image.new("RGB", (panel_w * len(panels), panel_h + 42), "white")
    draw = ImageDraw.Draw(canvas)
    for i, (title, arr) in enumerate(panels):
        im = Image.fromarray(arr).resize((panel_w, panel_h), Image.Resampling.BILINEAR)
        canvas.paste(im, (i * panel_w, 42))
        draw.text((i * panel_w + 12, 12), title, fill=(15, 23, 42))
    canvas.save(FIG_DIR / "sample_predictions_grid.png")

    Image.fromarray(overlay_image(img, true)).save(FIG_DIR / "sample_true_overlay.png")
    Image.fromarray(overlay_image(img, sem_pred)).save(FIG_DIR / "sample_semantic_prediction_overlay.png")
    Image.fromarray(overlay_image(img, box_pred)).save(FIG_DIR / "sample_bbox_prediction_overlay.png")


def save_metrics_tables(
    final_results: Sequence[Dict[str, object]],
    history: Sequence[Dict[str, object]],
    bbox_upper: Dict[str, object],
    detection_rows: Sequence[Dict[str, object]],
) -> None:
    write_csv(ANALYSIS_DIR / "training_history.csv", list(history))
    rows = []
    for result in final_results:
        for split in ("train", "validation", "test"):
            metrics = result["splits"][split]["metrics_vs_semantic"]
            rows.append(
                {
                    "model": result["model"],
                    "split": split,
                    "best_epoch": result["best_epoch"],
                    "loss_on_training_label": result["splits"][split]["loss_on_training_label"],
                    **metrics,
                }
            )
    for row in bbox_upper["rows"]:
        rows.append(row)
    write_csv(ANALYSIS_DIR / "model_metrics_summary.csv", rows)
    write_csv(ANALYSIS_DIR / "bbox_detection_metrics.csv", list(detection_rows))
    (ANALYSIS_DIR / "experiment_results.json").write_text(
        json.dumps(
            {
                "models": final_results,
                "bbox_label_upper_bound": bbox_upper,
                "bbox_detection_metrics": detection_rows,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def infer_overfitting(history: Sequence[Dict[str, object]], final_results: Sequence[Dict[str, object]]) -> Dict[str, object]:
    notes = {}
    for result in final_results:
        model = result["model"]
        rows = [r for r in history if r["model"] == model]
        last = rows[-1]
        best_epoch = int(result["best_epoch"])
        train_loss = float(last["train_loss"])
        val_loss = float(last["validation_loss_on_training_label"])
        gap = val_loss - train_loss
        best_val = float(result["best_validation_loss_on_training_label"])
        val_degradation = val_loss - best_val
        if gap > 0.25 and val_degradation > 0.10:
            status = "overfitting_signal"
        elif gap > 0.15:
            status = "mild_gap_watch"
        else:
            status = "no_strong_signal"
        notes[model] = {
            "best_epoch": best_epoch,
            "final_train_loss": train_loss,
            "final_validation_loss": val_loss,
            "final_gap_validation_minus_train": gap,
            "validation_degradation_after_best": val_degradation,
            "diagnosis": status,
        }
    (ANALYSIS_DIR / "overfitting_diagnosis.json").write_text(json.dumps(notes, ensure_ascii=False, indent=2), encoding="utf-8")
    return notes


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--steps", type=int, default=24)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--size", type=int, default=384)
    parser.add_argument("--patch-size", type=int, default=160)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    ensure_dirs()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.set_num_threads(max(1, min(4, os.cpu_count() or 2)))

    pairs = pair_files()
    summary = analyze_dataset(pairs, eval_size=args.size)
    plot_dataset_figures(pairs, summary)
    data = prepare_arrays(pairs, size=args.size)

    all_history: List[Dict[str, object]] = []
    final_results = []
    all_predictions: Dict[str, Dict[str, List[np.ndarray]]] = {}
    for model_name in ("semantic_mask", "bbox_mask"):
        final, history, preds = train_one(
            model_name,
            data,
            epochs=args.epochs,
            steps=args.steps,
            batch_size=args.batch_size,
            patch_size=args.patch_size,
            seed=args.seed + (0 if model_name == "semantic_mask" else 1000),
        )
        final_results.append(final)
        all_history.extend(history)
        all_predictions[model_name] = preds

    bbox_upper = evaluate_bbox_label_upper_bound(data)
    detection_rows = []
    for model_name in ("semantic_mask", "bbox_mask"):
        for threshold in (0.3, 0.5):
            metrics = detection_metrics(data["true_mask"]["test"], all_predictions[model_name]["test"], iou_threshold=threshold)
            detection_rows.append({"model": model_name, "split": "test", "iou_threshold": threshold, **metrics})

    plot_training_and_metrics(all_history, final_results, bbox_upper)
    create_qualitative_images(data, all_predictions)
    save_metrics_tables(final_results, all_history, bbox_upper, detection_rows)
    overfit = infer_overfitting(all_history, final_results)

    print(json.dumps({"dataset": summary, "overfitting": overfit}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
